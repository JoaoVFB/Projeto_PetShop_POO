//Joao Vitor Furquim de Brito - RA:2647990

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author joaov
 */
public class FormTosa extends javax.swing.JFrame {
    
    
    private Tosa to;
    private BDtosa gerTosa = BDtosa.geraGerTos();
   
   
    private static FormTosa formToUnic;
 
    private FormTosa() {
        initComponents();
    }
     //MÉTODO SINGLETON
    public static FormTosa getFormT(){
        if(formToUnic == null){
            formToUnic = new FormTosa();
        }
        return formToUnic;
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BGtipoTosa = new javax.swing.ButtonGroup();
        BGtipoShampoo = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        PanelMain = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        PanelCliente = new javax.swing.JPanel();
        lbDadosCliente = new javax.swing.JLabel();
        lbNome = new javax.swing.JLabel();
        txtNomeCliente = new javax.swing.JTextField();
        lbEndereco = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        lbTelefone = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        btnLimparCliente = new javax.swing.JButton();
        PanelDadosAnimal = new javax.swing.JPanel();
        LbDadosAnimal = new javax.swing.JLabel();
        LbNomeAnimal = new javax.swing.JLabel();
        LbRacaAnimal = new javax.swing.JLabel();
        txtNomeAnimal = new javax.swing.JTextField();
        txtRacaAnimal = new javax.swing.JTextField();
        LbPeso = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        txtIdadeAnimal = new javax.swing.JTextField();
        lbIdadeAnimal = new javax.swing.JLabel();
        btnLimparAnimal = new javax.swing.JButton();
        PanelAgendamento = new javax.swing.JPanel();
        lbAgendamento = new javax.swing.JLabel();
        lbData = new javax.swing.JLabel();
        txtData = new javax.swing.JTextField();
        lbHorario = new javax.swing.JLabel();
        txtHorario = new javax.swing.JTextField();
        btnLimparAgenda = new javax.swing.JButton();
        PanelTipoTosa = new javax.swing.JPanel();
        lbEscolhaTipo = new javax.swing.JLabel();
        RadioTosaMaquina = new javax.swing.JRadioButton();
        RadioTosaAdaptador = new javax.swing.JRadioButton();
        RadioTosaTesoura = new javax.swing.JRadioButton();
        btnLimparTipoTosa = new javax.swing.JButton();
        PanelDescricao = new javax.swing.JPanel();
        lbTxtArDescricao = new javax.swing.JLabel();
        btnLimparDescricao = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txArDescricao = new javax.swing.JTextArea();
        btnSalvar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnConsultar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblTosa = new javax.swing.JTable();
        btnAtualizar = new javax.swing.JButton();
        btnExBanId = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ListarTab = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("ID:");

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        PanelCliente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbDadosCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbDadosCliente.setText("Dados do Cliente: ");

        lbNome.setText("Nome: ");

        txtNomeCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeClienteActionPerformed(evt);
            }
        });

        lbEndereco.setText("Endereço:");

        txtEndereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEnderecoActionPerformed(evt);
            }
        });

        lbTelefone.setText("Telefone:");

        txtTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefoneActionPerformed(evt);
            }
        });

        btnLimparCliente.setText("Limpar");
        btnLimparCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelClienteLayout = new javax.swing.GroupLayout(PanelCliente);
        PanelCliente.setLayout(PanelClienteLayout);
        PanelClienteLayout.setHorizontalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelClienteLayout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(lbNome)
                                .addGap(25, 25, 25))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                                        .addComponent(lbTelefone)
                                        .addGap(16, 16, 16))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                                        .addComponent(lbEndereco)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))))
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                            .addComponent(txtNomeCliente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtTelefone, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbDadosCliente)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparCliente)))
                .addContainerGap())
        );
        PanelClienteLayout.setVerticalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbDadosCliente)
                .addGap(18, 18, 18)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbNome))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbTelefone)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbEndereco))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnLimparCliente)
                .addContainerGap())
        );

        PanelDadosAnimal.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelDadosAnimal.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        LbDadosAnimal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        LbDadosAnimal.setText("Dados do animal: ");

        LbNomeAnimal.setText("Nome: ");

        LbRacaAnimal.setText("Raça:");

        txtNomeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeAnimalActionPerformed(evt);
            }
        });

        txtRacaAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRacaAnimalActionPerformed(evt);
            }
        });

        LbPeso.setText("Peso (KG): ");

        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });

        txtIdadeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdadeAnimalActionPerformed(evt);
            }
        });

        lbIdadeAnimal.setText("Idade (anos): ");

        btnLimparAnimal.setText("Limpar");
        btnLimparAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAnimalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelDadosAnimalLayout = new javax.swing.GroupLayout(PanelDadosAnimal);
        PanelDadosAnimal.setLayout(PanelDadosAnimalLayout);
        PanelDadosAnimalLayout.setHorizontalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LbNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LbPeso)
                            .addComponent(LbRacaAnimal)
                            .addComponent(lbIdadeAnimal))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNomeAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                            .addComponent(txtPeso, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtRacaAnimal, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtIdadeAnimal)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelDadosAnimalLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparAnimal)))
                .addContainerGap())
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LbDadosAnimal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelDadosAnimalLayout.setVerticalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LbDadosAnimal)
                .addGap(18, 18, 18)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbNomeAnimal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LbRacaAnimal)
                    .addComponent(txtRacaAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbPeso))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdadeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbIdadeAnimal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(btnLimparAnimal)
                .addContainerGap())
        );

        PanelAgendamento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAgendamento.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbAgendamento.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbAgendamento.setText("Agendamento: ");

        lbData.setText("Data (formato: yyyy-MM-dd):");

        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        lbHorario.setText("Horario (formato: HH:mm):");

        txtHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHorarioActionPerformed(evt);
            }
        });

        btnLimparAgenda.setText("Limpar");
        btnLimparAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAgendaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelAgendamentoLayout = new javax.swing.GroupLayout(PanelAgendamento);
        PanelAgendamento.setLayout(PanelAgendamentoLayout);
        PanelAgendamentoLayout.setHorizontalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLimparAgenda))
                    .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                        .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtData, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                                    .addComponent(lbData)
                                    .addComponent(lbHorario)
                                    .addComponent(txtHorario)))
                            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lbAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        PanelAgendamentoLayout.setVerticalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbAgendamento)
                .addGap(18, 18, 18)
                .addComponent(lbData)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbHorario)
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addComponent(btnLimparAgenda)
                        .addGap(14, 14, 14))))
        );

        PanelTipoTosa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelTipoTosa.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbEscolhaTipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbEscolhaTipo.setText("Escolha um tipo de tosa: ");

        BGtipoTosa.add(RadioTosaMaquina);
        RadioTosaMaquina.setText("Tosa na máquina");
        RadioTosaMaquina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTosaMaquinaActionPerformed(evt);
            }
        });

        BGtipoTosa.add(RadioTosaAdaptador);
        RadioTosaAdaptador.setText("Tosa no adaptador");
        RadioTosaAdaptador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTosaAdaptadorActionPerformed(evt);
            }
        });

        BGtipoTosa.add(RadioTosaTesoura);
        RadioTosaTesoura.setText("Tosa na tesoura");
        RadioTosaTesoura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTosaTesouraActionPerformed(evt);
            }
        });

        btnLimparTipoTosa.setText("Limpar");
        btnLimparTipoTosa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparTipoTosaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelTipoTosaLayout = new javax.swing.GroupLayout(PanelTipoTosa);
        PanelTipoTosa.setLayout(PanelTipoTosaLayout);
        PanelTipoTosaLayout.setHorizontalGroup(
            PanelTipoTosaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoTosaLayout.createSequentialGroup()
                .addGroup(PanelTipoTosaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelTipoTosaLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(PanelTipoTosaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RadioTosaAdaptador)
                            .addComponent(RadioTosaMaquina)
                            .addComponent(RadioTosaTesoura))
                        .addGap(0, 148, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelTipoTosaLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparTipoTosa)))
                .addContainerGap())
            .addGroup(PanelTipoTosaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbEscolhaTipo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelTipoTosaLayout.setVerticalGroup(
            PanelTipoTosaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoTosaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbEscolhaTipo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RadioTosaMaquina)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RadioTosaAdaptador)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioTosaTesoura)
                .addGap(66, 66, 66)
                .addComponent(btnLimparTipoTosa)
                .addGap(71, 71, 71))
        );

        PanelDescricao.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelDescricao.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbTxtArDescricao.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbTxtArDescricao.setText("Descrição da tosa:");

        btnLimparDescricao.setText("Limpar");
        btnLimparDescricao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparDescricaoActionPerformed(evt);
            }
        });

        txArDescricao.setColumns(20);
        txArDescricao.setRows(5);
        jScrollPane3.setViewportView(txArDescricao);

        javax.swing.GroupLayout PanelDescricaoLayout = new javax.swing.GroupLayout(PanelDescricao);
        PanelDescricao.setLayout(PanelDescricaoLayout);
        PanelDescricaoLayout.setHorizontalGroup(
            PanelDescricaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDescricaoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelDescricaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelDescricaoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparDescricao))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 610, Short.MAX_VALUE)
                    .addGroup(PanelDescricaoLayout.createSequentialGroup()
                        .addComponent(lbTxtArDescricao)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        PanelDescricaoLayout.setVerticalGroup(
            PanelDescricaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDescricaoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbTxtArDescricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLimparDescricao)
                .addGap(11, 11, 11))
        );

        btnSalvar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnSair.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnConsultar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        tblTosa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome Cliente", "Endereço", "Telefone", "Nome Animal", "Raça", "Peso (kg)", "Idade (anos)", "Data ", "Horário", "Tipo De Tosa", "Descrição", "Duração (min.)", "Preço"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false, false, false, true, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblTosa);
        if (tblTosa.getColumnModel().getColumnCount() > 0) {
            tblTosa.getColumnModel().getColumn(0).setMinWidth(15);
            tblTosa.getColumnModel().getColumn(1).setMinWidth(120);
            tblTosa.getColumnModel().getColumn(2).setMinWidth(120);
            tblTosa.getColumnModel().getColumn(3).setMinWidth(120);
            tblTosa.getColumnModel().getColumn(4).setMinWidth(90);
            tblTosa.getColumnModel().getColumn(5).setMinWidth(80);
            tblTosa.getColumnModel().getColumn(6).setMinWidth(30);
            tblTosa.getColumnModel().getColumn(7).setMinWidth(30);
            tblTosa.getColumnModel().getColumn(8).setMinWidth(70);
            tblTosa.getColumnModel().getColumn(9).setMinWidth(70);
            tblTosa.getColumnModel().getColumn(11).setMinWidth(150);
            tblTosa.getColumnModel().getColumn(12).setMinWidth(90);
            tblTosa.getColumnModel().getColumn(13).setMinWidth(40);
        }

        btnAtualizar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        btnExBanId.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnExBanId.setText("Excluir pelo ID");
        btnExBanId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExBanIdActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel1.setText("Agendamento de Tosa");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Tabela de agendamentos de tosa");

        ListarTab.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        ListarTab.setText("Atualizar tabela");
        ListarTab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarTabActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelMainLayout = new javax.swing.GroupLayout(PanelMain);
        PanelMain.setLayout(PanelMainLayout);
        PanelMainLayout.setHorizontalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(805, 805, 805)
                        .addComponent(jLabel1))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(btnExBanId)
                        .addGap(18, 18, 18)
                        .addComponent(btnAtualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnConsultar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PanelAgendamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PanelTipoTosa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(PanelDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ListarTab, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1375, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        PanelMainLayout.setVerticalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(jLabel3)
                        .addGap(2, 2, 2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelMainLayout.createSequentialGroup()
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ListarTab))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PanelAgendamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(PanelTipoTosa, javax.swing.GroupLayout.PREFERRED_SIZE, 217, Short.MAX_VALUE))))
                .addGap(18, 18, 18)
                .addComponent(PanelDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExBanId)
                    .addComponent(btnAtualizar)
                    .addComponent(btnConsultar)
                    .addComponent(btnSalvar)
                    .addComponent(btnSair))
                .addGap(226, 226, 226))
        );

        jScrollPane1.setViewportView(PanelMain);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1931, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 851, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExBanIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExBanIdActionPerformed
        excluir();
        listarTab();

    }//GEN-LAST:event_btnExBanIdActionPerformed

    private void ListarTabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarTabActionPerformed
        listarTab();
    }//GEN-LAST:event_ListarTabActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        atualizar();

    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        consultar();        // TODO add your handling code here:
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?", "Cancelar Agendamento", WIDTH);
        if(sair == 0){
            limpar();
            this.dispose();
        }
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        to = new Tosa();
        if(txtNomeCliente.getText().isEmpty() || txtEndereco.getText().isEmpty() || txtTelefone.getText().isEmpty() ||
            txtNomeAnimal.getText().isEmpty() || txtPeso.getText().isEmpty() || txtRacaAnimal.getText().isEmpty() || txtIdadeAnimal.getText().isEmpty() ||
            txtData.getText().isEmpty() || txtHorario.getText().isEmpty() || txtId.getText().isEmpty() ||
            !RadioTosaAdaptador.isSelected() && !RadioTosaMaquina.isSelected() && !RadioTosaTesoura.isSelected() || txArDescricao.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Preencha todos os campos.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }else if(salvarCliente(to) == null || salvarDadosAnimal(to) == null || salvarAgendamento(to) == null || salvarId(to) == null || salvarDescricao(to) == null){
            JOptionPane.showMessageDialog(this, "Corrija os erros antes de continuar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
        else if(!RadioTosaAdaptador.isSelected() && !RadioTosaMaquina.isSelected() && !RadioTosaTesoura.isSelected()){
            JOptionPane.showMessageDialog(this, "Por favor, selecione uma das opções de Tosa!", "ERRO" , JOptionPane.ERROR_MESSAGE);
        }
        else {

            // Algum radio button está selecionado
            if(RadioTosaAdaptador.isSelected() ){
                to.setTipoDeTosa(RadioTosaAdaptador.getText());
            }else if(RadioTosaMaquina.isSelected()){
                to.setTipoDeTosa(RadioTosaMaquina.getText());
            }else{
                to.setTipoDeTosa(RadioTosaTesoura.getText());
            }
            
            
            to = salvarId(to);
            to = salvarCliente(to);
            to = salvarDadosAnimal(to);
            to = salvarAgendamento(to);
            to = salvarDescricao(to);
            to.calcPreco();
            to = gerTosa.insTosa(to);

            if(to != null){
                JOptionPane.showMessageDialog(null, "Agendamento realizado com sucesso!", "Salvando dados", JOptionPane.INFORMATION_MESSAGE);
                listarTab();
                limpar();
            }
            else{
                JOptionPane.showMessageDialog(null, "Já existe um agendamento com esse ID", "Erro de agendamento", JOptionPane.ERROR_MESSAGE);
                txtId.setText("");
                txtId.requestFocus();
            }

        }

        //verificando tipo de banho

        //verificando tipo de shampoo

    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnLimparDescricaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparDescricaoActionPerformed
        txArDescricao.setText("");
    }//GEN-LAST:event_btnLimparDescricaoActionPerformed

    private void btnLimparTipoTosaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparTipoTosaActionPerformed
        BGtipoTosa.clearSelection();
    }//GEN-LAST:event_btnLimparTipoTosaActionPerformed

    private void RadioTosaTesouraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTosaTesouraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTosaTesouraActionPerformed

    private void RadioTosaAdaptadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTosaAdaptadorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTosaAdaptadorActionPerformed

    private void RadioTosaMaquinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTosaMaquinaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTosaMaquinaActionPerformed

    private void btnLimparAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAgendaActionPerformed
        txtHorario.setText("");
        txtData.setText("");
    }//GEN-LAST:event_btnLimparAgendaActionPerformed

    private void txtHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHorarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHorarioActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void btnLimparAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAnimalActionPerformed
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
    }//GEN-LAST:event_btnLimparAnimalActionPerformed

    private void txtIdadeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdadeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdadeAnimalActionPerformed

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoActionPerformed

    private void txtRacaAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRacaAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRacaAnimalActionPerformed

    private void txtNomeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeAnimalActionPerformed

    private void btnLimparClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparClienteActionPerformed
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
    }//GEN-LAST:event_btnLimparClienteActionPerformed

    private void txtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneActionPerformed

    private void txtEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnderecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEnderecoActionPerformed

    private void txtNomeClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeClienteActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed
    
    public void atualizar(){
        to = new Tosa();
        boolean valido = true;
        int id = 0;
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do agendamento que será atualizado."));
            
         }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            valido = false;
        }
        
        //ba.setId(Integer.parseInt(txtId.getText()));
        if(valido){
            to.setId(id);
            to = gerTosa.consTosa(to);
            if(to != null){
                
                FormAtuTo.getFormAtuToUnic().dados(to);
                FormAtuTo.getFormAtuToUnic().setVisible(true);
                
                   //fab.listarTabB(ba);
                   //fcb.setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Não existe agendamento com esse ID", "Erro", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    
    public Tosa salvarId(Tosa to){
        boolean valido = true;
        
        try{
            to.setId(Integer.parseInt(txtId.getText()));
        }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números no campo ID.", "Erro de agendamento", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtId.setText("");
            txtId.requestFocus();
            
        }
        if(valido){
            return to;
        }
        else{
            return null;
        }
    }
public Tosa salvarCliente(Tosa to) {
    boolean valido = true; // Controle de validação

    // Validação do nome
    try {
        to.getAgenda().getAnimal().getDono().setNome(txtNomeCliente.getText());
    } catch (NomeNegException nne) {
        JOptionPane.showMessageDialog(this, "Informe apenas letras no NOME", "Erro", JOptionPane.ERROR_MESSAGE);
        txtNomeCliente.setText("");
        valido = false;
    }

    // Validação de telefone e endereço (apenas verificando campos obrigatórios)
    if (txtTelefone.getText().isEmpty() || txtEndereco.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Preencha todos os campos obrigatórios", "Erro", JOptionPane.ERROR_MESSAGE);
        valido = false;
    }

    // Se tudo estiver válido, salvar os dados
    if (valido) {
        to.getAgenda().getAnimal().getDono().setFone(txtTelefone.getText());
        to.getAgenda().getAnimal().getDono().setEndereco(txtEndereco.getText());
        return to; // Retorna apenas se todas as validações passarem
    } else {
        return null; // Não salvar enquanto houver erro
    }
}//Fim do método

//salvando dados do animal
public Tosa salvarDadosAnimal(Tosa to){
    to.getAgenda().getAnimal().setNome(txtNomeAnimal.getText());
    boolean valido = true;
		
    try {
        to.getAgenda().getAnimal().setPeso(Double.parseDouble(txtPeso.getText()));
        
    }catch (NumNegException p) {
        JOptionPane.showMessageDialog(null, "Informe um número maior que 0 no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE );
        valido = false;
        txtPeso.setText("");
    }catch (NumberFormatException nfe) {
        JOptionPane.showMessageDialog(null,"Informe apenas números no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtPeso.setText("");
    }
    
    try {
	to.getAgenda().getAnimal().setIdade(Integer.parseInt(txtIdadeAnimal.getText()));
	
    } catch (IdadeNegException ine) {
        JOptionPane.showMessageDialog(null,"Informe um número maior que 0 para IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtIdadeAnimal.setText("");
    } catch (NumberFormatException nfe) {
        JOptionPane.showMessageDialog(null,"Informe um número inteiro no campo IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtIdadeAnimal.setText("");
    }   
		
   
    try {
	to.getAgenda().getAnimal().setRaca(txtRacaAnimal.getText());
	
    }catch(RacaNumException rne) {
        JOptionPane.showMessageDialog(null,"Informe apenas letras no campo RAÇA.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtRacaAnimal.setText("");
    }   
        
    if (valido){
        return to;
    }
    else{
        return null;
    } 
} //Fim do metodo


//Salvar agendamento
public Tosa salvarAgendamento(Tosa to){
    boolean valido = true;
    //entrada da data
    try {
	to.getAgenda().setData(LocalDate.parse(txtData.getText()));
        
    }catch (DateTimeParseException e) {
	JOptionPane.showMessageDialog(null, "Formato de data inválido! Por favor, use o formato: yyyy-MM-dd.", "Erro", JOptionPane.ERROR_MESSAGE);
        txtData.setText("");
        valido = false;
    }
		
    //entrada da hora
    try {
	to.getAgenda().setHora(LocalTime.parse(txtHorario.getText()));
	
    } catch (IllegalArgumentException e) {
	JOptionPane.showMessageDialog(null, "Este horário está fora do horário de funcionamento (8 horas - 18 horas)!  ", "Erro", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtHorario.setText(""); 
    }
    catch (DateTimeParseException e) {
	JOptionPane.showMessageDialog(null, "Formato de horário inválido! Por favor, use o formato: HH:mm.", "Erro", JOptionPane.ERROR_MESSAGE);
	valido = false;
        txtHorario.setText(""); 
        
    }   
    if(valido){
        return to;
    }
    else{
        return null;
    }
} //fim do metodo 

    public Tosa salvarDescricao(Tosa to){
        if(txArDescricao.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Informe uma descrição para a tosa", "Erro", 0);
        }else{
            to.setDescricao(txArDescricao.getText());
            return to;
        }
        return null;
    }
    
//metodo Limpar tudo
    public void limpar(){
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
        txtHorario.setText("");
        txtData.setText("");
        BGtipoTosa.clearSelection();
        txArDescricao.setText("");
        txtId.setText("");
        
    }
    
    public void consultar(){
        to = new Tosa();
        //boolean valido = true;
        int id = 0;
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do agendamento para a consulta."));
            
            to.setId(id);
            to = gerTosa.consTosa(to);
            if(to != null){
                   FormConsTo.getFormConsTo().listarTabT(to);
                   FormConsTo.getFormConsTo().setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Não existe agendamento com esse ID", "Erro", JOptionPane.INFORMATION_MESSAGE);
            }
        
         }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            //valido = false;
        }
        
        //ba.setId(Integer.parseInt(txtId.getText()));
        
        
        
        
    }
    
    public void listarTab(){
          DefaultTableModel modelo = (DefaultTableModel) tblTosa.getModel();
          int posLin = 0;
          
         modelo.setRowCount(posLin);
        
        for(Tosa t: gerTosa.geraGerTos().getGerTos() ){
            modelo.insertRow(posLin, new Object []{t.getId(), t.getAgenda().getAnimal().getDono().getNome(),
                                t.getAgenda().getAnimal().getDono().getEndereco(),
                                t.getAgenda().getAnimal().getDono().getFone(),
                                t.getAgenda().getAnimal().getNome(),
                                t.getAgenda().getAnimal().getRaca(),
                                t.getAgenda().getAnimal().getPeso(),
                                t.getAgenda().getAnimal().getIdade(),
                                t.getAgenda().getData(),
                                t.getAgenda().getHora(),
                                t.getTipoDeTosa(),
                                t.getDescricao(),
                                t.duracaoServico(),
                                t.getPreco()
                                });
        }
    }
    
    public void excluir(){
        Tosa to = new Tosa();
        int id;
        
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe um ID para exclusão"));
            to.setId(id);
            to = gerTosa.consTosa(to);
            if(to != null){
                int ver = JOptionPane.showConfirmDialog(null, "Deseja realmente excluir esse agendamento?", "Confirmação de exclusão", JOptionPane.YES_NO_CANCEL_OPTION);
                if( ver == 0){
                    gerTosa.delTosaId(to);
                    JOptionPane.showMessageDialog(null, "Agendamento  excluído com sucesso.", "Exclusão de agendamento", 1);
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Não existe um agendemento com esse ID", "Erro de Exclusão", JOptionPane.ERROR_MESSAGE);
            }
            
        }catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormTosa().setVisible(true);
                    
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BGtipoShampoo;
    private javax.swing.ButtonGroup BGtipoTosa;
    private javax.swing.JLabel LbDadosAnimal;
    private javax.swing.JLabel LbNomeAnimal;
    private javax.swing.JLabel LbPeso;
    private javax.swing.JLabel LbRacaAnimal;
    private javax.swing.JButton ListarTab;
    private javax.swing.JPanel PanelAgendamento;
    private javax.swing.JPanel PanelCliente;
    private javax.swing.JPanel PanelDadosAnimal;
    private javax.swing.JPanel PanelDescricao;
    private javax.swing.JPanel PanelMain;
    private javax.swing.JPanel PanelTipoTosa;
    private javax.swing.JRadioButton RadioTosaAdaptador;
    private javax.swing.JRadioButton RadioTosaMaquina;
    private javax.swing.JRadioButton RadioTosaTesoura;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnExBanId;
    private javax.swing.JButton btnLimparAgenda;
    private javax.swing.JButton btnLimparAnimal;
    private javax.swing.JButton btnLimparCliente;
    private javax.swing.JButton btnLimparDescricao;
    private javax.swing.JButton btnLimparTipoTosa;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lbAgendamento;
    private javax.swing.JLabel lbDadosCliente;
    private javax.swing.JLabel lbData;
    private javax.swing.JLabel lbEndereco;
    private javax.swing.JLabel lbEscolhaTipo;
    private javax.swing.JLabel lbHorario;
    private javax.swing.JLabel lbIdadeAnimal;
    private javax.swing.JLabel lbNome;
    private javax.swing.JLabel lbTelefone;
    private javax.swing.JLabel lbTxtArDescricao;
    private javax.swing.JTable tblTosa;
    private javax.swing.JTextArea txArDescricao;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtHorario;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtIdadeAnimal;
    private javax.swing.JTextField txtNomeAnimal;
    private javax.swing.JTextField txtNomeCliente;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtRacaAnimal;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
