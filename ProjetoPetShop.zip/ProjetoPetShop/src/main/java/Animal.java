//Joao Vitor Furquim de Brito - RA:2647990

public class Animal {
	private String nome;
	private int idade;
	private double peso;
	private String raca;
	private Cliente dono;
	

	public Animal() {
		nome = "";
		idade = 0;
		peso = 0.0;
		raca = "";
		dono = new Cliente();
	}

	public String getNome() {
		return nome;
	}

	public int getIdade() {
		return idade;
	}

	public double getPeso() {
		return peso;
	}

	public String getRaca() {
		return raca;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setIdade(int idade) throws IdadeNegException{
		if(idade > 0) {
			this.idade = idade;
		}else {
			throw new IdadeNegException();
		}
		
	}

	public void setPeso(double peso) throws NumNegException{
		if(peso > 0) {
			this.peso = peso;
		}else {
			throw new NumNegException();
		}
	}

	public void setRaca(String raca) throws RacaNumException {
		for(int i=0; i< raca.length(); i++) {
			char c = raca.charAt(i);
			if(Character.isDigit(c)) {
				throw new RacaNumException();
			}
		}
		this.raca = raca;
	}

	public Cliente getDono() {
		return dono;
	}

	public void setDono(Cliente dono){
		this.dono = dono;
	}
	

}