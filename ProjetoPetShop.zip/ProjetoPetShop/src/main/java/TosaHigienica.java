//Joao Vitor Furquim de Brito - RA: 2647990

public class TosaHigienica extends Servico implements Duracao{
	private String tipoDeTosaHig;
	private String adicional;
	
	//tipo 1: banho com tosa higienica normal
	//tipo 2: banho com tosa hiogienica patinha raspada
	
	public TosaHigienica() {
		tipoDeTosaHig = "";
		adicional = "";
	}

	public String getAdicional() {
		return adicional;
	}

	public void setAdicional(String adicional) {
		this.adicional = adicional;
	}

	public String getTipoDeTosaHig() {
		return tipoDeTosaHig;
	}

	public void setTipoDeTosaHig(String tipoDeTosaHig) {
		this.tipoDeTosaHig = tipoDeTosaHig;
	}


	public void salvarAdicional(int op) {
		if(op == 1) {
			setAdicional("Corte de unha");
		}else if(op == 2){
			setAdicional("Limpeza de ouvido");
		}else if(op == 3) {
			setAdicional("Corte de unha e limpeza de ouvido");
		}
		else {
			setAdicional("Nenhum adicional");
		}
	}
	
	
        
	public String duracaoServico() {
		if(getTipoDeTosaHig() == "Tosa higiénica normal" ) {
                    return "75";
		}else {
                    return "90";
		}
	}
	
	//metodo abstrato sobrescrito da classe "Servico"
	public void calcPreco() {
		if(tipoDeTosaHig == "Tosa higiénica normal") {
			if(super.getAgenda().getAnimal().getPeso() <= 10.0) {
				super.setPreco(45.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() > 10 && super.getAgenda().getAnimal().getPeso() < 20) {
				super.setPreco(55.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() >= 20 && super.getAgenda().getAnimal().getPeso() < 40) {
				super.setPreco(70.00);
			}
			else{
				super.setPreco(90.00);
			}
		}else {
			if(super.getAgenda().getAnimal().getPeso() <= 10.0) {
				super.setPreco(50.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() > 10 && super.getAgenda().getAnimal().getPeso() < 20) {
				super.setPreco(60.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() >= 20 && super.getAgenda().getAnimal().getPeso() < 40) {
				super.setPreco(75.00);
			}
			else{
				super.setPreco(95.00);
			}
		}
	}
}
