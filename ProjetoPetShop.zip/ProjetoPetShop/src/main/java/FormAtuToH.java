//Joao Vitor Furquim de Brito - RA:2647990

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author joaov
 */
public class FormAtuToH extends javax.swing.JFrame {

    
    private static FormAtuToH formAtuToHUnic;
    
    private FormAtuToH() {
        initComponents();
    }
     //MÉTODO SINGLETON
    public static FormAtuToH geraFormAtuToHUnic(){
        if(formAtuToHUnic == null){
            formAtuToHUnic = new FormAtuToH();
        }
        return formAtuToHUnic;
    }
    
    
    private TosaHigienica th = new TosaHigienica();
    public BDtosaHig gerTosH = BDtosaHig.geraBDtosaHig();
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BGAdicional = new javax.swing.ButtonGroup();
        BGtipoTosaH = new javax.swing.ButtonGroup();
        PanelAdicional = new javax.swing.JPanel();
        lbAdicional = new javax.swing.JLabel();
        RadioCorteUnha = new javax.swing.JRadioButton();
        RadioLimpezaOuvido = new javax.swing.JRadioButton();
        RadioCorteUnhaLimpOuvido = new javax.swing.JRadioButton();
        RadioNenhum = new javax.swing.JRadioButton();
        btnLimparAdicional = new javax.swing.JButton();
        PanelTipoBanho = new javax.swing.JPanel();
        lbEscolhaTipoTosaH = new javax.swing.JLabel();
        RadioTosaHigNormal = new javax.swing.JRadioButton();
        RadioTosaPataInvertida = new javax.swing.JRadioButton();
        btnLimparTipoTosaH = new javax.swing.JButton();
        PanelDadosAnimal = new javax.swing.JPanel();
        LbDadosAnimal = new javax.swing.JLabel();
        LbNomeAnimal = new javax.swing.JLabel();
        LbRacaAnimal = new javax.swing.JLabel();
        txtNomeAnimal = new javax.swing.JTextField();
        txtRacaAnimal = new javax.swing.JTextField();
        LbPeso = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        txtIdadeAnimal = new javax.swing.JTextField();
        lbIdadeAnimal = new javax.swing.JLabel();
        btnLimparAnimal = new javax.swing.JButton();
        PanelCliente = new javax.swing.JPanel();
        lbDadosCliente = new javax.swing.JLabel();
        lbNome = new javax.swing.JLabel();
        txtNomeCliente = new javax.swing.JTextField();
        lbEndereco = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        lbTelefone = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        btnLimparCliente = new javax.swing.JButton();
        PanelAgendamento = new javax.swing.JPanel();
        lbAgendamento = new javax.swing.JLabel();
        lbData = new javax.swing.JLabel();
        txtData = new javax.swing.JTextField();
        lbHorario = new javax.swing.JLabel();
        txtHorario = new javax.swing.JTextField();
        btnLimparAgenda = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        PanelAdicional.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAdicional.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbAdicional.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbAdicional.setText("Escolha um serviço adicional:  ");

        BGAdicional.add(RadioCorteUnha);
        RadioCorteUnha.setText("Corte de unha");
        RadioCorteUnha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioCorteUnhaActionPerformed(evt);
            }
        });

        BGAdicional.add(RadioLimpezaOuvido);
        RadioLimpezaOuvido.setText("Limpeza de ouvido");
        RadioLimpezaOuvido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioLimpezaOuvidoActionPerformed(evt);
            }
        });

        BGAdicional.add(RadioCorteUnhaLimpOuvido);
        RadioCorteUnhaLimpOuvido.setText("Corte de unha e limpeza de ouvido");
        RadioCorteUnhaLimpOuvido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioCorteUnhaLimpOuvidoActionPerformed(evt);
            }
        });

        BGAdicional.add(RadioNenhum);
        RadioNenhum.setText("Nenhum");
        RadioNenhum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioNenhumActionPerformed(evt);
            }
        });

        btnLimparAdicional.setText("Limpar");
        btnLimparAdicional.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAdicionalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelAdicionalLayout = new javax.swing.GroupLayout(PanelAdicional);
        PanelAdicional.setLayout(PanelAdicionalLayout);
        PanelAdicionalLayout.setHorizontalGroup(
            PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAdicionalLayout.createSequentialGroup()
                .addGroup(PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbAdicional)
                    .addGroup(PanelAdicionalLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelAdicionalLayout.createSequentialGroup()
                                .addComponent(RadioNenhum)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnLimparAdicional)
                                .addGap(10, 10, 10))
                            .addGroup(PanelAdicionalLayout.createSequentialGroup()
                                .addGroup(PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(RadioLimpezaOuvido)
                                    .addComponent(RadioCorteUnha)
                                    .addComponent(RadioCorteUnhaLimpOuvido))
                                .addGap(0, 74, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        PanelAdicionalLayout.setVerticalGroup(
            PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAdicionalLayout.createSequentialGroup()
                .addComponent(lbAdicional)
                .addGap(18, 18, 18)
                .addComponent(RadioCorteUnha)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioLimpezaOuvido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioCorteUnhaLimpOuvido)
                .addGroup(PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAdicionalLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                        .addComponent(btnLimparAdicional)
                        .addGap(17, 17, 17))
                    .addGroup(PanelAdicionalLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RadioNenhum)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        PanelTipoBanho.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelTipoBanho.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbEscolhaTipoTosaH.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbEscolhaTipoTosaH.setText("Escolha um tipo de Tosa Higiénica: ");

        BGtipoTosaH.add(RadioTosaHigNormal);
        RadioTosaHigNormal.setText("Tosa higiénica normal");
        RadioTosaHigNormal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTosaHigNormalActionPerformed(evt);
            }
        });

        BGtipoTosaH.add(RadioTosaPataInvertida);
        RadioTosaPataInvertida.setText("Tosa higiénica com pata invertida");
        RadioTosaPataInvertida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTosaPataInvertidaActionPerformed(evt);
            }
        });

        btnLimparTipoTosaH.setText("Limpar");
        btnLimparTipoTosaH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparTipoTosaHActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelTipoBanhoLayout = new javax.swing.GroupLayout(PanelTipoBanho);
        PanelTipoBanho.setLayout(PanelTipoBanhoLayout);
        PanelTipoBanhoLayout.setHorizontalGroup(
            PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addGroup(PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                        .addGroup(PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbEscolhaTipoTosaH)
                            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addGroup(PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(RadioTosaPataInvertida)
                                    .addComponent(RadioTosaHigNormal))))
                        .addGap(0, 69, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelTipoBanhoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparTipoTosaH)))
                .addContainerGap())
        );
        PanelTipoBanhoLayout.setVerticalGroup(
            PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addComponent(lbEscolhaTipoTosaH)
                .addGap(30, 30, 30)
                .addComponent(RadioTosaHigNormal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioTosaPataInvertida)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addComponent(btnLimparTipoTosaH)
                .addGap(14, 14, 14))
        );

        PanelDadosAnimal.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelDadosAnimal.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        LbDadosAnimal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        LbDadosAnimal.setText("Dados do animal: ");

        LbNomeAnimal.setText("Nome: ");

        LbRacaAnimal.setText("Raça:");

        txtNomeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeAnimalActionPerformed(evt);
            }
        });

        txtRacaAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRacaAnimalActionPerformed(evt);
            }
        });

        LbPeso.setText("Peso (KG): ");

        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });

        txtIdadeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdadeAnimalActionPerformed(evt);
            }
        });

        lbIdadeAnimal.setText("Idade (anos): ");

        btnLimparAnimal.setText("Limpar");
        btnLimparAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAnimalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelDadosAnimalLayout = new javax.swing.GroupLayout(PanelDadosAnimal);
        PanelDadosAnimal.setLayout(PanelDadosAnimalLayout);
        PanelDadosAnimalLayout.setHorizontalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addComponent(LbDadosAnimal)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LbNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LbPeso)
                            .addComponent(LbRacaAnimal)
                            .addComponent(lbIdadeAnimal))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNomeAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                            .addComponent(txtPeso, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtRacaAnimal, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtIdadeAnimal)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelDadosAnimalLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLimparAnimal)))
                .addContainerGap())
        );
        PanelDadosAnimalLayout.setVerticalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(LbDadosAnimal)
                .addGap(18, 18, 18)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbNomeAnimal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LbRacaAnimal)
                    .addComponent(txtRacaAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbPeso))
                .addGap(9, 9, 9)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdadeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbIdadeAnimal))
                .addGap(18, 18, 18)
                .addComponent(btnLimparAnimal))
        );

        PanelCliente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbDadosCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbDadosCliente.setText("Dados do Cliente: ");

        lbNome.setText("Nome: ");

        txtNomeCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeClienteActionPerformed(evt);
            }
        });

        lbEndereco.setText("Endereço:");

        txtEndereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEnderecoActionPerformed(evt);
            }
        });

        lbTelefone.setText("Telefone:");

        txtTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefoneActionPerformed(evt);
            }
        });

        btnLimparCliente.setText("Limpar");
        btnLimparCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelClienteLayout = new javax.swing.GroupLayout(PanelCliente);
        PanelCliente.setLayout(PanelClienteLayout);
        PanelClienteLayout.setHorizontalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelClienteLayout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbNome)
                                    .addComponent(lbTelefone))
                                .addGap(10, 10, 10))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lbEndereco)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 229, Short.MAX_VALUE)
                            .addComponent(txtNomeCliente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtTelefone, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbDadosCliente)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparCliente)))
                .addContainerGap())
        );
        PanelClienteLayout.setVerticalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbDadosCliente)
                .addGap(18, 18, 18)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbNome))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTelefone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbEndereco))
                        .addGap(0, 84, Short.MAX_VALUE))
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparCliente)
                        .addContainerGap())))
        );

        PanelAgendamento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAgendamento.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbAgendamento.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbAgendamento.setText("Agendamento: ");

        lbData.setText("Data (formato: yyyy-MM-dd):");

        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        lbHorario.setText("Horario (formato: HH:mm):");

        txtHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHorarioActionPerformed(evt);
            }
        });

        btnLimparAgenda.setText("Limpar");
        btnLimparAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAgendaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelAgendamentoLayout = new javax.swing.GroupLayout(PanelAgendamento);
        PanelAgendamento.setLayout(PanelAgendamentoLayout);
        PanelAgendamentoLayout.setHorizontalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addComponent(lbAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtData, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                    .addComponent(lbData)
                    .addComponent(lbHorario)
                    .addComponent(txtHorario))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnLimparAgenda)
                .addContainerGap())
        );
        PanelAgendamentoLayout.setVerticalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbAgendamento)
                .addGap(18, 18, 18)
                .addComponent(lbData)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbHorario)
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addComponent(btnLimparAgenda)
                        .addGap(14, 14, 14))))
        );

        btnAtualizar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(380, Short.MAX_VALUE)
                .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(PanelAdicional, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(PanelAgendamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PanelTipoBanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(PanelAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PanelTipoBanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(PanelAdicional, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RadioCorteUnhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioCorteUnhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioCorteUnhaActionPerformed

    private void RadioLimpezaOuvidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioLimpezaOuvidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioLimpezaOuvidoActionPerformed

    private void RadioCorteUnhaLimpOuvidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioCorteUnhaLimpOuvidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioCorteUnhaLimpOuvidoActionPerformed

    private void RadioNenhumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioNenhumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioNenhumActionPerformed

    private void btnLimparAdicionalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAdicionalActionPerformed
        BGAdicional.clearSelection();
    }//GEN-LAST:event_btnLimparAdicionalActionPerformed

    private void RadioTosaHigNormalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTosaHigNormalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTosaHigNormalActionPerformed

    private void RadioTosaPataInvertidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTosaPataInvertidaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTosaPataInvertidaActionPerformed

    private void btnLimparTipoTosaHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparTipoTosaHActionPerformed
        BGtipoTosaH.clearSelection();
    }//GEN-LAST:event_btnLimparTipoTosaHActionPerformed

    private void txtNomeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeAnimalActionPerformed

    private void txtRacaAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRacaAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRacaAnimalActionPerformed

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoActionPerformed

    private void txtIdadeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdadeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdadeAnimalActionPerformed

    private void btnLimparAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAnimalActionPerformed
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
    }//GEN-LAST:event_btnLimparAnimalActionPerformed

    private void txtNomeClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeClienteActionPerformed

    private void txtEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnderecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEnderecoActionPerformed

    private void txtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneActionPerformed

    private void btnLimparClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparClienteActionPerformed
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
    }//GEN-LAST:event_btnLimparClienteActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void txtHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHorarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHorarioActionPerformed

    private void btnLimparAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAgendaActionPerformed
        txtHorario.setText("");
        txtData.setText("");
    }//GEN-LAST:event_btnLimparAgendaActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed

        if(txtNomeCliente.getText().isEmpty() || txtEndereco.getText().isEmpty() || txtTelefone.getText().isEmpty() ||
            txtNomeAnimal.getText().isEmpty() || txtPeso.getText().isEmpty() || txtRacaAnimal.getText().isEmpty() || txtIdadeAnimal.getText().isEmpty() ||
            txtData.getText().isEmpty() || txtHorario.getText().isEmpty()){

            JOptionPane.showMessageDialog(this, "Preencha todos os campos.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }else if(salvarCliente(th) == null || salvarDadosAnimal(th) == null || salvarAgendamento(th) == null){
            JOptionPane.showMessageDialog(this, "Corrija os erros antes de continuar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
        else if(!RadioCorteUnha.isSelected() && !RadioLimpezaOuvido.isSelected() && !RadioCorteUnhaLimpOuvido.isSelected() && !RadioNenhum.isSelected()){
            JOptionPane.showMessageDialog(this, "Por favor, selecione um serviço adicional!", "ERRO" , JOptionPane.ERROR_MESSAGE);
        }
        else if(!RadioTosaHigNormal.isSelected() && !RadioTosaPataInvertida.isSelected()){
            JOptionPane.showMessageDialog(this, "Por favor, selecione um tipo de tosa higiénica!", "ERRO" , JOptionPane.ERROR_MESSAGE);
        }
        else {

            // Algum radio button está selecionado
            if(RadioCorteUnha.isSelected() ){
                th.setAdicional(RadioCorteUnha.getText());
            }else if(RadioLimpezaOuvido.isSelected()){
                th.setAdicional(RadioLimpezaOuvido.getText());
            }else if(RadioCorteUnhaLimpOuvido.isSelected()){
                th.setAdicional(RadioCorteUnhaLimpOuvido.getText());
            }else{
                th.setAdicional(RadioNenhum.getText());
            }
            
            //Tipo de tosa higienica
            if(RadioTosaHigNormal.isSelected() ){
                th.setTipoDeTosaHig(RadioTosaHigNormal.getText());
            }else{
                th.setTipoDeTosaHig(RadioTosaPataInvertida.getText());
            }

            th = salvarCliente(th);
            th = salvarDadosAnimal(th);
            th = salvarAgendamento(th);
            
            th.calcPreco();
            th = gerTosH.atualizarTosaHig(th);

            if(th != null){
                JOptionPane.showMessageDialog(null, "Agendamento atualizado com sucesso!", "Atualização de dados", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showInternalMessageDialog(null, "Atualize a tabela para visualizar os novos dados.", "Atualização de dados", 1);
                setVisible(false);
                limpar();

            }

        }
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        sair();
        
    }//GEN-LAST:event_btnCancelarActionPerformed

    
    public TosaHigienica salvarCliente(TosaHigienica th) {
    boolean valido = true; // Controle de validação

        // Validação do nome
        try {
            th.getAgenda().getAnimal().getDono().setNome(txtNomeCliente.getText());
        } catch (NomeNegException nne) {
            JOptionPane.showMessageDialog(this, "Informe apenas letras no NOME", "Erro", JOptionPane.ERROR_MESSAGE);
            txtNomeCliente.setText("");
            valido = false;
        }


        // Validação de telefone e endereço (apenas verificando campos obrigatórios)
        if (txtTelefone.getText().isEmpty() || txtEndereco.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos obrigatórios", "Erro", JOptionPane.ERROR_MESSAGE);
            valido = false;
        }

        // Se tudo estiver válido, salvar os dados
        if (valido) {
            th.getAgenda().getAnimal().getDono().setFone(txtTelefone.getText());
            th.getAgenda().getAnimal().getDono().setEndereco(txtEndereco.getText());
            return th; // Retorna apenas se todas as validações passarem
        } else {
            return null; // Não salvar enquanto houver erro
        }
    }//Fim do método
    
    //salvando dados do animal
    public TosaHigienica salvarDadosAnimal(TosaHigienica th){
        th.getAgenda().getAnimal().setNome(txtNomeAnimal.getText());
        boolean valido = true;

        try {
            th.getAgenda().getAnimal().setPeso(Double.parseDouble(txtPeso.getText()));

        }catch (NumNegException p) {
            JOptionPane.showMessageDialog(null, "Informe um número maior que 0 no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE );
            valido = false;
            txtPeso.setText("");
        }catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null,"Informe apenas números no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtPeso.setText("");
        }

        try {
            th.getAgenda().getAnimal().setIdade(Integer.parseInt(txtIdadeAnimal.getText()));

        } catch (IdadeNegException ine) {
            JOptionPane.showMessageDialog(null,"Informe um número maior que 0 para IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtIdadeAnimal.setText("");
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null,"Informe um número inteiro no campo IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtIdadeAnimal.setText("");
        }   


        try {
            th.getAgenda().getAnimal().setRaca(txtRacaAnimal.getText());

        }catch(RacaNumException rne) {
            JOptionPane.showMessageDialog(null,"Informe apenas letras no campo RAÇA.", "ERRO", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtRacaAnimal.setText("");
        }   

        if (valido){
            return th;
        }
        else{
            return null;
        } 
    } //Fim do metodo
    
    //Salvar agendamento
    public TosaHigienica salvarAgendamento(TosaHigienica to){
        boolean valido = true;
        //entrada da data
        try {
            to.getAgenda().setData(LocalDate.parse(txtData.getText()));

        }catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(null, "Formato de data inválido! Por favor, use o formato: yyyy-MM-dd.", "Erro", JOptionPane.ERROR_MESSAGE);
            txtData.setText("");
            valido = false;
        }

        //entrada da hora
        try {
            to.getAgenda().setHora(LocalTime.parse(txtHorario.getText()));

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Este horário está fora do horário de funcionamento (8 horas - 18 horas)!  ", "Erro", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtHorario.setText(""); 
        }
        catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(null, "Formato de horário inválido! Por favor, use o formato: HH:mm.", "Erro", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtHorario.setText(""); 

        }   
        if(valido){
            return to;
        }
        else{
            return null;
        }
    } //fim do metodo 
    
    //metodo Limpar tudo
    public void limpar(){
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
        txtHorario.setText("");
        txtData.setText("");
        BGAdicional.clearSelection();
        BGtipoTosaH.clearSelection();
       
    }
    
    public void dados(TosaHigienica th){
        txtNomeCliente.setText(th.getAgenda().getAnimal().getDono().getNome());
        txtEndereco.setText(th.getAgenda().getAnimal().getDono().getEndereco());
        txtTelefone.setText(th.getAgenda().getAnimal().getDono().getFone());
        txtNomeAnimal.setText(th.getAgenda().getAnimal().getNome());
        txtRacaAnimal.setText(th.getAgenda().getAnimal().getRaca());
        txtPeso.setText(Double.toString(th.getAgenda().getAnimal().getPeso()));
        txtIdadeAnimal.setText(Integer.toString(th.getAgenda().getAnimal().getIdade()));
        txtData.setText(th.getAgenda().getData().toString());
        txtHorario.setText(th.getAgenda().getHora().toString());
        this.th = th;
    }
    
    //metodo para sair
    public void sair(){
        int x = JOptionPane.showConfirmDialog(null, "Deseja realmente sair?", "Cancelar atualização de dados", WIDTH);
        if(x == 0){
            limpar();
            FormAtuToH.geraFormAtuToHUnic().setVisible(false);
        }
    }
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormAtuToH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormAtuToH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormAtuToH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormAtuToH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormAtuToH().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BGAdicional;
    private javax.swing.ButtonGroup BGtipoTosaH;
    private javax.swing.JLabel LbDadosAnimal;
    private javax.swing.JLabel LbNomeAnimal;
    private javax.swing.JLabel LbPeso;
    private javax.swing.JLabel LbRacaAnimal;
    private javax.swing.JPanel PanelAdicional;
    private javax.swing.JPanel PanelAgendamento;
    private javax.swing.JPanel PanelCliente;
    private javax.swing.JPanel PanelDadosAnimal;
    private javax.swing.JPanel PanelTipoBanho;
    private javax.swing.JRadioButton RadioCorteUnha;
    private javax.swing.JRadioButton RadioCorteUnhaLimpOuvido;
    private javax.swing.JRadioButton RadioLimpezaOuvido;
    private javax.swing.JRadioButton RadioNenhum;
    private javax.swing.JRadioButton RadioTosaHigNormal;
    private javax.swing.JRadioButton RadioTosaPataInvertida;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnLimparAdicional;
    private javax.swing.JButton btnLimparAgenda;
    private javax.swing.JButton btnLimparAnimal;
    private javax.swing.JButton btnLimparCliente;
    private javax.swing.JButton btnLimparTipoTosaH;
    private javax.swing.JLabel lbAdicional;
    private javax.swing.JLabel lbAgendamento;
    private javax.swing.JLabel lbDadosCliente;
    private javax.swing.JLabel lbData;
    private javax.swing.JLabel lbEndereco;
    private javax.swing.JLabel lbEscolhaTipoTosaH;
    private javax.swing.JLabel lbHorario;
    private javax.swing.JLabel lbIdadeAnimal;
    private javax.swing.JLabel lbNome;
    private javax.swing.JLabel lbTelefone;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtHorario;
    private javax.swing.JTextField txtIdadeAnimal;
    private javax.swing.JTextField txtNomeAnimal;
    private javax.swing.JTextField txtNomeCliente;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtRacaAnimal;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
