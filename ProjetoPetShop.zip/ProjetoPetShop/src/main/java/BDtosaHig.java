//Joao Vitor Furquim de Brito - RA:2647990

import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joaov
 */
public class BDtosaHig {
    
    private TosaHigienica th;
    private List<TosaHigienica> gerTosaHig;
    
    private static BDtosaHig bdTosaHigUnic;
    
    private BDtosaHig(){
        th = new TosaHigienica();
        gerTosaHig = new ArrayList<TosaHigienica>();
    }
     //MÉTODO SINGLETON
    public static BDtosaHig geraBDtosaHig(){
        if(bdTosaHigUnic == null){
            bdTosaHigUnic = new BDtosaHig();
        }
        return bdTosaHigUnic;
    }
    
    public List<TosaHigienica> getGerTosaHig(){
            return gerTosaHig;
        }
        
	//Consultar dados
	public TosaHigienica consTosaHig(TosaHigienica th){
		for(int i = 0; i < gerTosaHig.size(); i++){
			if(th.getId() == gerTosaHig.get(i).getId()){
				return gerTosaHig.get(i);
			}
		}
		return null;
	}//fim consBanNum
	
	//inserir dados
	public TosaHigienica insTosaHig(TosaHigienica th) {
		if(consTosaHig(th) == null) {
			gerTosaHig.add(th);
			return th;
		}else {
			return null;
		}
	}//fim do insTosaHigienica
	
	//atualizar Tosa Higienica
	public TosaHigienica atualizarTosaHig(TosaHigienica th){ //Nao atualiza o num, apenas os demais campos
		for(int i = 0; i < gerTosaHig.size(); i++){
			if(th.getId() == gerTosaHig.get(i).getId()){
                            th = gerTosaHig.get(i);
                            gerTosaHig.set(i, th);  
                            return gerTosaHig.get(i);
			}
		}
                return null;
	}//fim atualizar tosa higienica
	
        //Excluir Tosa Higienica
        public TosaHigienica delTosaHigId(TosaHigienica th){
           
            TosaHigienica th1 = consTosaHig(th);
            if(th1 != null){
                gerTosaHig.remove(th1);
                return null;
            }
            else{
                return th;
            }
	
        }//fim do delTosaHigId
}
