//Joao Vitor Furquim de Brito - RA:2647990

public class Banho extends  Servico implements Duracao {
	private  String tipoDeBanho;
	private String tipoDeShampoo;
	
	
	public Banho() {
		tipoDeBanho ="";
		tipoDeShampoo = "";
	}

	public String getTipoDeShampoo() {
		return tipoDeShampoo;
	}
	public String  getTipoDeBanho() {
		return tipoDeBanho;
	}

	public void setTipoDeBanho( String tipoDeBanho) {
		this.tipoDeBanho = tipoDeBanho;
	}
	public void setTipoDeShampoo(String tipoDeShampoo) {
		this.tipoDeShampoo = tipoDeShampoo;
	}

	
	public void salvarTipoShampoo(int op) {
		
		
	}
	
	
	//metodo abstrato sobrescrito da classe base servico para calcular o valor do banho 
	public void calcPreco() {
		if(tipoDeBanho == "Normal" ) {
			if(super.getAgenda().getAnimal().getPeso() <= 10.0) {
				super.setPreco(35.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() > 10 && super.getAgenda().getAnimal().getPeso() < 20) {
				super.setPreco(45.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() >= 20 && super.getAgenda().getAnimal().getPeso() < 40) {
				super.setPreco(60.00);
			}
			else{
				super.setPreco(80.00);
			}
			
		}else if(tipoDeBanho == "Hidratação" ) {
			if(super.getAgenda().getAnimal().getPeso() <= 10.0) {
				super.setPreco(45.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() > 10 && super.getAgenda().getAnimal().getPeso() < 20) {
				super.setPreco(55.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() >= 20 && super.getAgenda().getAnimal().getPeso() < 40) {
				super.setPreco(70.00);
			}
			else{
				super.setPreco(90.00);
			}
		}else {
			if(super.getAgenda().getAnimal().getPeso() <= 10.0) {
				super.setPreco(40.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() > 10 && super.getAgenda().getAnimal().getPeso() < 20) {
				super.setPreco(50.00);
			}
			else if(super.getAgenda().getAnimal().getPeso() >= 20 && super.getAgenda().getAnimal().getPeso() < 40) {
				super.setPreco(65.00);
			}
			else{
				super.setPreco(85.00);
			}
		}		
	}
	
	//intereface para calcular a duracao do servico
	public String duracaoServico() {
		if(getTipoDeBanho() == "Normal") {
			return "60";
		}else {
			return "75";
		}
		
	}

	
}
