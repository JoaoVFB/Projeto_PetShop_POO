//Joao Vitor Furquim de Brito - RA: 2647990

public interface Duracao {
	
	public String duracaoServico();
	
}
