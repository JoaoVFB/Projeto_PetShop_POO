//Joao Vitor Furquim de Brito - RA:2647990

import java.time.LocalDate;
import java.time.LocalTime;



public class Agendamento {
	private LocalDate data;
	private LocalTime hora;
	private Animal animal;
	
	public Agendamento() {
		animal = new Animal();
	}
	

	public LocalDate getData() {
		return data;
	}

	public LocalTime getHora() {
		return hora;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}

	public void setHora(LocalTime horario) {
	    if (horario.isBefore(LocalTime.of(8, 0)) || horario.isAfter(LocalTime.of(18, 0))) {
	        throw new IllegalArgumentException("O horário deve estar entre 08:00 e 18:00.");
	    }
	    this.hora = horario;
	}
	public Animal getAnimal() {
		return animal;
	}

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}

	
	
}