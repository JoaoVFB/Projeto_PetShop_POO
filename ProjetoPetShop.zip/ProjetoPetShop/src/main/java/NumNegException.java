//Joao Vitor Furquim de Brito - RA: 2647990

public class NumNegException extends Exception{
	public NumNegException(){
		super();
	}
}
