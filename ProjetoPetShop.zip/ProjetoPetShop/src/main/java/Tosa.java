//Joao Vitor Furquim de Brito - RA: 2647990

public class Tosa extends Servico implements Duracao{
	
	private String tipoDeTosa;
	private String descricao;
	
	//construtor 
	public Tosa(){
		tipoDeTosa = "";
		descricao = "";
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public String getTipoDeTosa() {
		return tipoDeTosa;
	}
	
	public void setTipoDeTosa(String tipoDeTosa){
		this.tipoDeTosa = tipoDeTosa;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	//Sobrescricao do metodo abstrato da classe mae servico para calcular o valor da tosa 
	public void calcPreco(){
		if(tipoDeTosa == "Tosa na máquina"){
                    super.setPreco(60.00);
		}else if(tipoDeTosa == "Tosa no adaptador") {
                    super.setPreco(80.00);
		}else {
                    super.setPreco(100.00);
		}
	}
	
	//interface
	public String duracaoServico() {
		if(getTipoDeTosa() == "Tosa na máquina" ) {
			return "75";
		}else if(getTipoDeTosa() == "Tosa no adaptador") { 
			return "90";
		}else {
			return "120";
		}
	}

}
