//Joao Vitor Furquim de Brito - RA:2647990

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author joaov
 */
public class FormTosaHig extends javax.swing.JFrame {
    
    
    private TosaHigienica th;
    private BDtosaHig gerTH = BDtosaHig.geraBDtosaHig();
   
    private static FormTosaHig formTHUnic;
  
    
    
    private FormTosaHig() {
        initComponents();
    }
     //MÉTODO SINGLETON
    public static FormTosaHig getFormTH(){
        if(formTHUnic == null){
            formTHUnic = new FormTosaHig();
        }
        return formTHUnic;
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BGtipoTosaH = new javax.swing.ButtonGroup();
        BGAdicional = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        PanelMain = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        PanelCliente = new javax.swing.JPanel();
        lbDadosCliente = new javax.swing.JLabel();
        lbNome = new javax.swing.JLabel();
        txtNomeCliente = new javax.swing.JTextField();
        lbEndereco = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        lbTelefone = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        btnLimparCliente = new javax.swing.JButton();
        PanelDadosAnimal = new javax.swing.JPanel();
        LbDadosAnimal = new javax.swing.JLabel();
        LbNomeAnimal = new javax.swing.JLabel();
        LbRacaAnimal = new javax.swing.JLabel();
        txtNomeAnimal = new javax.swing.JTextField();
        txtRacaAnimal = new javax.swing.JTextField();
        LbPeso = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        txtIdadeAnimal = new javax.swing.JTextField();
        lbIdadeAnimal = new javax.swing.JLabel();
        btnLimparAnimal = new javax.swing.JButton();
        PanelAgendamento = new javax.swing.JPanel();
        lbAgendamento = new javax.swing.JLabel();
        lbData = new javax.swing.JLabel();
        txtData = new javax.swing.JTextField();
        lbHorario = new javax.swing.JLabel();
        txtHorario = new javax.swing.JTextField();
        btnLimparAgenda = new javax.swing.JButton();
        PanelTipoBanho = new javax.swing.JPanel();
        lbEscolhaTipoTosaH = new javax.swing.JLabel();
        RadioTosaHigNormal = new javax.swing.JRadioButton();
        RadioTosaPataInvertida = new javax.swing.JRadioButton();
        btnLimparTipoTosaH = new javax.swing.JButton();
        PanelAdicional = new javax.swing.JPanel();
        lbAdicional = new javax.swing.JLabel();
        RadioCorteUnha = new javax.swing.JRadioButton();
        RadioLimpezaOuvido = new javax.swing.JRadioButton();
        RadioCorteUnhaLimpOuvido = new javax.swing.JRadioButton();
        RadioNenhum = new javax.swing.JRadioButton();
        btnLimparAdicional = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnConsultar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblBanho = new javax.swing.JTable();
        btnAtualizar = new javax.swing.JButton();
        btnExBanId = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ListarTab = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("ID:");

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        PanelCliente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbDadosCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbDadosCliente.setText("Dados do Cliente: ");

        lbNome.setText("Nome: ");

        txtNomeCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeClienteActionPerformed(evt);
            }
        });

        lbEndereco.setText("Endereço:");

        txtEndereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEnderecoActionPerformed(evt);
            }
        });

        lbTelefone.setText("Telefone:");

        txtTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefoneActionPerformed(evt);
            }
        });

        btnLimparCliente.setText("Limpar");
        btnLimparCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelClienteLayout = new javax.swing.GroupLayout(PanelCliente);
        PanelCliente.setLayout(PanelClienteLayout);
        PanelClienteLayout.setHorizontalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(PanelClienteLayout.createSequentialGroup()
                                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbNome)
                                    .addComponent(lbTelefone))
                                .addGap(26, 26, 26))
                            .addGroup(PanelClienteLayout.createSequentialGroup()
                                .addComponent(lbEndereco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                            .addComponent(txtNomeCliente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtTelefone, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbDadosCliente)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparCliente)))
                .addContainerGap())
        );
        PanelClienteLayout.setVerticalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbDadosCliente)
                .addGap(18, 18, 18)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbNome))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTelefone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbEndereco)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(btnLimparCliente)
                        .addContainerGap())))
        );

        PanelDadosAnimal.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelDadosAnimal.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        LbDadosAnimal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        LbDadosAnimal.setText("Dados do animal: ");

        LbNomeAnimal.setText("Nome: ");

        LbRacaAnimal.setText("Raça:");

        txtNomeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeAnimalActionPerformed(evt);
            }
        });

        txtRacaAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRacaAnimalActionPerformed(evt);
            }
        });

        LbPeso.setText("Peso (KG): ");

        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });

        txtIdadeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdadeAnimalActionPerformed(evt);
            }
        });

        lbIdadeAnimal.setText("Idade (anos): ");

        btnLimparAnimal.setText("Limpar");
        btnLimparAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAnimalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelDadosAnimalLayout = new javax.swing.GroupLayout(PanelDadosAnimal);
        PanelDadosAnimal.setLayout(PanelDadosAnimalLayout);
        PanelDadosAnimalLayout.setHorizontalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LbNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LbPeso)
                            .addComponent(LbRacaAnimal)
                            .addComponent(lbIdadeAnimal))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNomeAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                            .addComponent(txtPeso, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtRacaAnimal, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtIdadeAnimal)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelDadosAnimalLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLimparAnimal)))
                .addContainerGap())
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LbDadosAnimal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelDadosAnimalLayout.setVerticalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LbDadosAnimal)
                .addGap(18, 18, 18)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbNomeAnimal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LbRacaAnimal)
                    .addComponent(txtRacaAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbPeso))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdadeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbIdadeAnimal))
                .addGap(18, 18, 18)
                .addComponent(btnLimparAnimal)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        PanelAgendamento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAgendamento.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbAgendamento.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbAgendamento.setText("Agendamento: ");

        lbData.setText("Data (formato: yyyy-MM-dd):");

        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        lbHorario.setText("Horario (formato: HH:mm):");

        txtHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHorarioActionPerformed(evt);
            }
        });

        btnLimparAgenda.setText("Limpar");
        btnLimparAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAgendaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelAgendamentoLayout = new javax.swing.GroupLayout(PanelAgendamento);
        PanelAgendamento.setLayout(PanelAgendamentoLayout);
        PanelAgendamentoLayout.setHorizontalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLimparAgenda))
                    .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                        .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtData, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                                    .addComponent(lbData)
                                    .addComponent(lbHorario)
                                    .addComponent(txtHorario)))
                            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lbAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        PanelAgendamentoLayout.setVerticalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbAgendamento)
                .addGap(18, 18, 18)
                .addComponent(lbData)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbHorario)
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addComponent(btnLimparAgenda)
                        .addGap(14, 14, 14))))
        );

        PanelTipoBanho.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelTipoBanho.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbEscolhaTipoTosaH.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbEscolhaTipoTosaH.setText("Escolha um tipo de Tosa Higiénica: ");

        BGtipoTosaH.add(RadioTosaHigNormal);
        RadioTosaHigNormal.setText("Tosa higiénica normal");
        RadioTosaHigNormal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTosaHigNormalActionPerformed(evt);
            }
        });

        BGtipoTosaH.add(RadioTosaPataInvertida);
        RadioTosaPataInvertida.setText("Tosa higiénica com pata invertida");
        RadioTosaPataInvertida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTosaPataInvertidaActionPerformed(evt);
            }
        });

        btnLimparTipoTosaH.setText("Limpar");
        btnLimparTipoTosaH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparTipoTosaHActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelTipoBanhoLayout = new javax.swing.GroupLayout(PanelTipoBanho);
        PanelTipoBanho.setLayout(PanelTipoBanhoLayout);
        PanelTipoBanhoLayout.setHorizontalGroup(
            PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addGroup(PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RadioTosaPataInvertida)
                            .addComponent(RadioTosaHigNormal))
                        .addGap(0, 69, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelTipoBanhoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparTipoTosaH)))
                .addContainerGap())
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbEscolhaTipoTosaH)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelTipoBanhoLayout.setVerticalGroup(
            PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbEscolhaTipoTosaH)
                .addGap(24, 24, 24)
                .addComponent(RadioTosaHigNormal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioTosaPataInvertida)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addComponent(btnLimparTipoTosaH)
                .addGap(14, 14, 14))
        );

        PanelAdicional.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAdicional.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbAdicional.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbAdicional.setText("Escolha um serviço adicional:  ");

        BGAdicional.add(RadioCorteUnha);
        RadioCorteUnha.setText("Corte de unha");
        RadioCorteUnha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioCorteUnhaActionPerformed(evt);
            }
        });

        BGAdicional.add(RadioLimpezaOuvido);
        RadioLimpezaOuvido.setText("Limpeza de ouvido");
        RadioLimpezaOuvido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioLimpezaOuvidoActionPerformed(evt);
            }
        });

        BGAdicional.add(RadioCorteUnhaLimpOuvido);
        RadioCorteUnhaLimpOuvido.setText("Corte de unha e limpeza de ouvido");
        RadioCorteUnhaLimpOuvido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioCorteUnhaLimpOuvidoActionPerformed(evt);
            }
        });

        BGAdicional.add(RadioNenhum);
        RadioNenhum.setText("Nenhum");
        RadioNenhum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioNenhumActionPerformed(evt);
            }
        });

        btnLimparAdicional.setText("Limpar");
        btnLimparAdicional.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAdicionalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelAdicionalLayout = new javax.swing.GroupLayout(PanelAdicional);
        PanelAdicional.setLayout(PanelAdicionalLayout);
        PanelAdicionalLayout.setHorizontalGroup(
            PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAdicionalLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAdicionalLayout.createSequentialGroup()
                        .addComponent(RadioNenhum)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 151, Short.MAX_VALUE)
                        .addComponent(btnLimparAdicional)
                        .addGap(10, 10, 10))
                    .addGroup(PanelAdicionalLayout.createSequentialGroup()
                        .addGroup(PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RadioLimpezaOuvido)
                            .addComponent(RadioCorteUnha)
                            .addComponent(RadioCorteUnhaLimpOuvido))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(PanelAdicionalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbAdicional)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        PanelAdicionalLayout.setVerticalGroup(
            PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAdicionalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbAdicional)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RadioCorteUnha)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioLimpezaOuvido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioCorteUnhaLimpOuvido)
                .addGroup(PanelAdicionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAdicionalLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                        .addComponent(btnLimparAdicional)
                        .addGap(17, 17, 17))
                    .addGroup(PanelAdicionalLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RadioNenhum)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        btnSalvar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnSair.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnConsultar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        tblBanho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome Cliente", "Endereço", "Telefone", "Nome Animal", "Raça", "Peso (kg)", "Idade (anos)", "Data ", "Horário", "Tipo De Tosa Hig.", "Adicional", "Duração (min.)", "Preço"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblBanho);
        if (tblBanho.getColumnModel().getColumnCount() > 0) {
            tblBanho.getColumnModel().getColumn(0).setMinWidth(35);
            tblBanho.getColumnModel().getColumn(1).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(2).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(3).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(4).setMinWidth(90);
            tblBanho.getColumnModel().getColumn(5).setMinWidth(80);
            tblBanho.getColumnModel().getColumn(6).setMinWidth(45);
            tblBanho.getColumnModel().getColumn(7).setMinWidth(50);
            tblBanho.getColumnModel().getColumn(8).setMinWidth(100);
            tblBanho.getColumnModel().getColumn(9).setMinWidth(70);
            tblBanho.getColumnModel().getColumn(10).setMinWidth(150);
            tblBanho.getColumnModel().getColumn(11).setMinWidth(150);
            tblBanho.getColumnModel().getColumn(12).setMinWidth(100);
            tblBanho.getColumnModel().getColumn(13).setMinWidth(60);
        }

        btnAtualizar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        btnExBanId.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnExBanId.setText("Excluir pelo ID");
        btnExBanId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExBanIdActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel1.setText("Agendamento de tosa higiénica");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Tabela de agendamentos de tosa higiénica");

        ListarTab.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        ListarTab.setText("Atualizar tabela");
        ListarTab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarTabActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelMainLayout = new javax.swing.GroupLayout(PanelMain);
        PanelMain.setLayout(PanelMainLayout);
        PanelMainLayout.setHorizontalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(805, 805, 805)
                        .addComponent(jLabel1))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(btnExBanId)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAtualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnConsultar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PanelAdicional, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PanelAgendamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(PanelTipoBanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(34, 34, 34)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ListarTab, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1298, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(90, Short.MAX_VALUE))
        );
        PanelMainLayout.setVerticalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(jLabel3)
                        .addGap(2, 2, 2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelMainLayout.createSequentialGroup()
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ListarTab))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PanelTipoBanho, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(PanelAgendamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PanelAdicional, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExBanId)
                    .addComponent(btnAtualizar)
                    .addComponent(btnConsultar)
                    .addComponent(btnSalvar)
                    .addComponent(btnSair))
                .addGap(188, 188, 188))
        );

        jScrollPane1.setViewportView(PanelMain);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1953, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 851, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExBanIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExBanIdActionPerformed
        excluir();
        listarTab();

    }//GEN-LAST:event_btnExBanIdActionPerformed

    private void ListarTabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarTabActionPerformed
        listarTab();
    }//GEN-LAST:event_ListarTabActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        atualizar();

    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        consultar();        // TODO add your handling code here:
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?", "Cancelar Agendamento", WIDTH);
        if(sair == 0){
            limpar();
            this.dispose();
        }
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        th = new TosaHigienica();
        if(txtNomeCliente.getText().isEmpty() || txtEndereco.getText().isEmpty() || txtTelefone.getText().isEmpty() ||
            txtNomeAnimal.getText().isEmpty() || txtPeso.getText().isEmpty() || txtRacaAnimal.getText().isEmpty() || txtIdadeAnimal.getText().isEmpty() ||
            txtData.getText().isEmpty() || txtHorario.getText().isEmpty() || txtId.getText().isEmpty() ||
            !RadioTosaPataInvertida.isSelected() && !RadioTosaHigNormal.isSelected() ||
            !RadioCorteUnha.isSelected() && !RadioLimpezaOuvido.isSelected() && !RadioCorteUnhaLimpOuvido.isSelected() && !RadioNenhum.isSelected()){
            JOptionPane.showMessageDialog(this, "Preencha todos os campos.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }else if(salvarCliente(th) == null || salvarDadosAnimal(th) == null || salvarAgendamento(th) == null || salvarId(th) == null){
            JOptionPane.showMessageDialog(this, "Corrija os erros antes de continuar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
        else if(!RadioTosaPataInvertida.isSelected() && !RadioTosaHigNormal.isSelected()){
            JOptionPane.showMessageDialog(this, "Por favor, selecione uma das opções de tosa higiénica!", "ERRO" , JOptionPane.ERROR_MESSAGE);
        }
        else if(!RadioCorteUnha.isSelected() && !RadioLimpezaOuvido.isSelected() && !RadioCorteUnhaLimpOuvido.isSelected() && !RadioNenhum.isSelected()){
            JOptionPane.showMessageDialog(this, "Por favor, selecione uma das opções de adicionais!", "ERRO" , JOptionPane.ERROR_MESSAGE);
        }
        else {

            // Algum radio button está selecionado
            if(RadioTosaPataInvertida.isSelected() ){
                th.setTipoDeTosaHig(RadioTosaPataInvertida.getText());
            }else{
                th.setTipoDeTosaHig(RadioTosaHigNormal.getText());
            }
            
            if(RadioCorteUnha.isSelected() ){
                th.setAdicional(RadioCorteUnha.getText());
            }else if(RadioLimpezaOuvido.isSelected()){
                th.setAdicional(RadioLimpezaOuvido.getText());
            }else if(RadioCorteUnhaLimpOuvido.isSelected()){
                th.setAdicional(RadioCorteUnhaLimpOuvido.getText());
            }else{
                th.setAdicional(RadioNenhum.getText());
            }
            
            th = salvarId(th);
            th = salvarCliente(th);
            th = salvarDadosAnimal(th);
            th = salvarAgendamento(th);
            th.calcPreco();
            th = gerTH.insTosaHig(th);

            if(th != null){
                JOptionPane.showMessageDialog(null, "Agendamento realizado com sucesso!", "Salvando dados", JOptionPane.INFORMATION_MESSAGE);
                listarTab();
                limpar();
            }
            else{
                JOptionPane.showMessageDialog(null, "Já existe um agendamento com esse ID", "Erro de agendamento", JOptionPane.ERROR_MESSAGE);
                txtId.setText("");
                txtId.requestFocus();
            }

        }

        //verificando tipo de banho

        //verificando tipo de shampoo

    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnLimparAdicionalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAdicionalActionPerformed
        BGAdicional.clearSelection();
    }//GEN-LAST:event_btnLimparAdicionalActionPerformed

    private void RadioCorteUnhaLimpOuvidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioCorteUnhaLimpOuvidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioCorteUnhaLimpOuvidoActionPerformed

    private void RadioLimpezaOuvidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioLimpezaOuvidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioLimpezaOuvidoActionPerformed

    private void RadioCorteUnhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioCorteUnhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioCorteUnhaActionPerformed

    private void btnLimparTipoTosaHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparTipoTosaHActionPerformed
        BGtipoTosaH.clearSelection();
    }//GEN-LAST:event_btnLimparTipoTosaHActionPerformed

    private void RadioTosaPataInvertidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTosaPataInvertidaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTosaPataInvertidaActionPerformed

    private void RadioTosaHigNormalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTosaHigNormalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTosaHigNormalActionPerformed

    private void btnLimparAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAgendaActionPerformed
        txtHorario.setText("");
        txtData.setText("");
    }//GEN-LAST:event_btnLimparAgendaActionPerformed

    private void txtHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHorarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHorarioActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void btnLimparAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAnimalActionPerformed
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
    }//GEN-LAST:event_btnLimparAnimalActionPerformed

    private void txtIdadeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdadeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdadeAnimalActionPerformed

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoActionPerformed

    private void txtRacaAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRacaAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRacaAnimalActionPerformed

    private void txtNomeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeAnimalActionPerformed

    private void btnLimparClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparClienteActionPerformed
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
    }//GEN-LAST:event_btnLimparClienteActionPerformed

    private void txtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneActionPerformed

    private void txtEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnderecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEnderecoActionPerformed

    private void txtNomeClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeClienteActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void RadioNenhumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioNenhumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioNenhumActionPerformed
    
    public void atualizar(){
        th = new TosaHigienica();
        boolean valido = true;
        int id = 0;
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do agendamento que será atualizado."));
            
         }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            valido = false;
        }
        
        
        if(valido){
            th.setId(id);
            th = gerTH.consTosaHig(th);
            if(th != null){
                
                FormAtuToH.geraFormAtuToHUnic().dados(th);
                FormAtuToH.geraFormAtuToHUnic().setVisible(true);
                
                   //fab.listarTabB(ba);
                   //fcb.setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Não existe agendamento com esse ID", "Erro", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    
    public TosaHigienica salvarId(TosaHigienica th){
        boolean valido = true;
        
        try{
            th.setId(Integer.parseInt(txtId.getText()));
        }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números no campo ID.", "Erro de agendamento", JOptionPane.ERROR_MESSAGE);
            txtId.setText("");
            txtId.requestFocus();
            valido = false;
        }
        if(valido){
            return th;
        }
        else{
            return null;
        }
    }
public TosaHigienica salvarCliente(TosaHigienica th) {
    boolean valido = true; // Controle de validação

    // Validação do nome
    try {
        th.getAgenda().getAnimal().getDono().setNome(txtNomeCliente.getText());
    } catch (NomeNegException nne) {
        JOptionPane.showMessageDialog(this, "Informe apenas letras no NOME", "Erro", JOptionPane.ERROR_MESSAGE);
        txtNomeCliente.setText("");
        valido = false;
    }

    // Validação de telefone e endereço (apenas verificando campos obrigatórios)
    if (txtTelefone.getText().isEmpty() || txtEndereco.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Preencha todos os campos obrigatórios", "Erro", JOptionPane.ERROR_MESSAGE);
        valido = false;
    }

    // Se tudo estiver válido, salvar os dados
    if (valido) {
        th.getAgenda().getAnimal().getDono().setFone(txtTelefone.getText());
        th.getAgenda().getAnimal().getDono().setEndereco(txtEndereco.getText());
        return th; // Retorna apenas se todas as validações passarem
    } else {
        return null; // Não salvar enquanto houver erro
    }
}//Fim do método

//salvando dados do animal
public TosaHigienica salvarDadosAnimal(TosaHigienica th){
    th.getAgenda().getAnimal().setNome(txtNomeAnimal.getText());
    boolean valido = true;
		
    try {
        th.getAgenda().getAnimal().setPeso(Double.parseDouble(txtPeso.getText()));
        
    }catch (NumNegException p) {
        JOptionPane.showMessageDialog(null, "Informe um número maior que 0 no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE );
        valido = false;
        txtPeso.setText("");
    }catch (NumberFormatException nfe) {
        JOptionPane.showMessageDialog(null,"Informe apenas números no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtPeso.setText("");
    }
    
    try {
	th.getAgenda().getAnimal().setIdade(Integer.parseInt(txtIdadeAnimal.getText()));
	
    } catch (IdadeNegException ine) {
        JOptionPane.showMessageDialog(null,"Informe um número maior que 0 para IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtIdadeAnimal.setText("");
    } catch (NumberFormatException nfe) {
        JOptionPane.showMessageDialog(null,"Informe um número inteiro no campo IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtIdadeAnimal.setText("");
    }   
		
   
    try {
	th.getAgenda().getAnimal().setRaca(txtRacaAnimal.getText());
	
    }catch(RacaNumException rne) {
        JOptionPane.showMessageDialog(null,"Informe apenas letras no campo RAÇA.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtRacaAnimal.setText("");
    }   
        
    if (valido){
        return th;
    }
    else{
        return null;
    } 
} //Fim do metodo


//Salvar agendamento
public TosaHigienica salvarAgendamento(TosaHigienica th){
    boolean valido = true;
    //entrada da data
    try {
	th.getAgenda().setData(LocalDate.parse(txtData.getText()));
        
    }catch (DateTimeParseException e) {
	JOptionPane.showMessageDialog(null, "Formato de data inválido! Por favor, use o formato: yyyy-MM-dd.", "Erro", JOptionPane.ERROR_MESSAGE);
        txtData.setText("");
        valido = false;
    }
		
    //entrada da hora
    try {
	th.getAgenda().setHora(LocalTime.parse(txtHorario.getText()));
	
    } catch (IllegalArgumentException e) {
	JOptionPane.showMessageDialog(null, "Este horário está fora do horário de funcionamento (8 horas - 18 horas)!  ", "Erro", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtHorario.setText(""); 
    }
    catch (DateTimeParseException e) {
	JOptionPane.showMessageDialog(null, "Formato de horário inválido! Por favor, use o formato: HH:mm.", "Erro", JOptionPane.ERROR_MESSAGE);
	valido = false;
        txtHorario.setText(""); 
        
    }   
    if(valido){
        return th;
    }
    else{
        return null;
    }
} //fim do metodo 
    
//metodo Limpar tudo
    public void limpar(){
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
        txtHorario.setText("");
        txtData.setText("");
        BGtipoTosaH.clearSelection();
        BGAdicional.clearSelection();
        txtId.setText("");
    }
    
    public void consultar(){
        th = new TosaHigienica();
        
        int id = 0;
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do agendamento para a consulta."));
            th.setId(id);
            th = gerTH.consTosaHig(th);
            if(th != null){
                   FormConsToH.getFormConsToH().listarTabH(th);
                   FormConsToH.getFormConsToH().setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Não existe agendamento com esse ID", "Erro", JOptionPane.INFORMATION_MESSAGE);
            }
         }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            
        }   
    }
    
    public void listarTab(){
          DefaultTableModel modelo = (DefaultTableModel) tblBanho.getModel();
          int posLin = 0;
          
         modelo.setRowCount(posLin);
        
        for(TosaHigienica th: gerTH.getGerTosaHig()){
            modelo.insertRow(posLin, new Object []{th.getId(), th.getAgenda().getAnimal().getDono().getNome(),
                                th.getAgenda().getAnimal().getDono().getEndereco(),
                                th.getAgenda().getAnimal().getDono().getFone(),
                                th.getAgenda().getAnimal().getNome(),
                                th.getAgenda().getAnimal().getRaca(),
                                th.getAgenda().getAnimal().getPeso(),
                                th.getAgenda().getAnimal().getIdade(),
                                th.getAgenda().getData(),
                                th.getAgenda().getHora(),
                                th.getTipoDeTosaHig(),
                                th.getAdicional(),
                                th.duracaoServico(),
                                th.getPreco()
                                });
        }
    }
    
    public void excluir(){
        TosaHigienica th = new TosaHigienica();
        int id;
        
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe um ID para exclusão"));
            th.setId(id);
            th = gerTH.consTosaHig(th);
            if(th != null){
                int ver = JOptionPane.showConfirmDialog(null, "Deseja realmente excluir esse agendamento?", "Confirmação de exclusão", JOptionPane.YES_NO_CANCEL_OPTION);
                if( ver == 0){
                    gerTH.delTosaHigId(th);
                    JOptionPane.showMessageDialog(null, "Agendamento  excluído com sucesso.", "Exclusão de agendamento", 1);
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Não existe um agendemento com esse ID", "Erro de Exclusão", JOptionPane.ERROR_MESSAGE);
            }
            
        }catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            
        }
 
    }
    
    
    
    
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormTosaHig().setVisible(true);
                    
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BGAdicional;
    private javax.swing.ButtonGroup BGtipoTosaH;
    private javax.swing.JLabel LbDadosAnimal;
    private javax.swing.JLabel LbNomeAnimal;
    private javax.swing.JLabel LbPeso;
    private javax.swing.JLabel LbRacaAnimal;
    private javax.swing.JButton ListarTab;
    private javax.swing.JPanel PanelAdicional;
    private javax.swing.JPanel PanelAgendamento;
    private javax.swing.JPanel PanelCliente;
    private javax.swing.JPanel PanelDadosAnimal;
    private javax.swing.JPanel PanelMain;
    private javax.swing.JPanel PanelTipoBanho;
    private javax.swing.JRadioButton RadioCorteUnha;
    private javax.swing.JRadioButton RadioCorteUnhaLimpOuvido;
    private javax.swing.JRadioButton RadioLimpezaOuvido;
    private javax.swing.JRadioButton RadioNenhum;
    private javax.swing.JRadioButton RadioTosaHigNormal;
    private javax.swing.JRadioButton RadioTosaPataInvertida;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnExBanId;
    private javax.swing.JButton btnLimparAdicional;
    private javax.swing.JButton btnLimparAgenda;
    private javax.swing.JButton btnLimparAnimal;
    private javax.swing.JButton btnLimparCliente;
    private javax.swing.JButton btnLimparTipoTosaH;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbAdicional;
    private javax.swing.JLabel lbAgendamento;
    private javax.swing.JLabel lbDadosCliente;
    private javax.swing.JLabel lbData;
    private javax.swing.JLabel lbEndereco;
    private javax.swing.JLabel lbEscolhaTipoTosaH;
    private javax.swing.JLabel lbHorario;
    private javax.swing.JLabel lbIdadeAnimal;
    private javax.swing.JLabel lbNome;
    private javax.swing.JLabel lbTelefone;
    private javax.swing.JTable tblBanho;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtHorario;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtIdadeAnimal;
    private javax.swing.JTextField txtNomeAnimal;
    private javax.swing.JTextField txtNomeCliente;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtRacaAnimal;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
