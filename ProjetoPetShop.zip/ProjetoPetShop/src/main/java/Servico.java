//Joao Vitor Furquim de Brito - RA: 2647990

public abstract class Servico {
	private double preco;
	private String descricao;
	private Agendamento agenda;
	private int id;
		

	public Servico() {
		preco = 0.0;
		descricao = "";
		agenda = new Agendamento();
		id = 0;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getPreco() {
		return preco;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Agendamento getAgenda() {
		return agenda;
	}

	public void setAgenda(Agendamento agenda) {
		this.agenda = agenda;
	}
	
	public abstract void calcPreco();
}
