//Joao Vitor Furquim de Brito - RA: 2647990

public class NomeNegException extends Exception{
	public NomeNegException() {}
}
