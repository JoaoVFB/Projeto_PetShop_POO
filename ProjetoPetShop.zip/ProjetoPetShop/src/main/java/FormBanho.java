//Joao Vitor Furquim de Brito - RA:2647990

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author joaov
 */
public class FormBanho extends javax.swing.JFrame {
    
    
    private Banho ba;
    private BDbanho gerBan = BDbanho.geraGerBan();
    
   
    private static FormBanho formBUnico;
  
    
    
    private FormBanho() {
        initComponents();
    }
 //MÉTODO SINGLETON
    public static FormBanho getFormB(){
        if(formBUnico == null){
            formBUnico = new FormBanho();
        }
        return formBUnico;
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BGtipoBanho = new javax.swing.ButtonGroup();
        BGtipoShampoo = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        PanelMain = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        PanelCliente = new javax.swing.JPanel();
        lbDadosCliente = new javax.swing.JLabel();
        lbNome = new javax.swing.JLabel();
        txtNomeCliente = new javax.swing.JTextField();
        lbEndereco = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        lbTelefone = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        btnLimparCliente = new javax.swing.JButton();
        PanelDadosAnimal = new javax.swing.JPanel();
        LbDadosAnimal = new javax.swing.JLabel();
        LbNomeAnimal = new javax.swing.JLabel();
        LbRacaAnimal = new javax.swing.JLabel();
        txtNomeAnimal = new javax.swing.JTextField();
        txtRacaAnimal = new javax.swing.JTextField();
        LbPeso = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        txtIdadeAnimal = new javax.swing.JTextField();
        lbIdadeAnimal = new javax.swing.JLabel();
        btnLimparAnimal = new javax.swing.JButton();
        PanelAgendamento = new javax.swing.JPanel();
        lbAgendamento = new javax.swing.JLabel();
        lbData = new javax.swing.JLabel();
        txtData = new javax.swing.JTextField();
        lbHorario = new javax.swing.JLabel();
        txtHorario = new javax.swing.JTextField();
        btnLimparAgenda = new javax.swing.JButton();
        PanelTipoBanho = new javax.swing.JPanel();
        lbEscolhaTipo = new javax.swing.JLabel();
        RadioBanhoNormal = new javax.swing.JRadioButton();
        RadioBanhoHidra = new javax.swing.JRadioButton();
        RadioBanhoRecons = new javax.swing.JRadioButton();
        btnLimparTipoBanho = new javax.swing.JButton();
        PanelTipoShampoo = new javax.swing.JPanel();
        lbTipoShampoo = new javax.swing.JLabel();
        RadioShampooNeutro = new javax.swing.JRadioButton();
        RadioShampooLimpPro = new javax.swing.JRadioButton();
        RadioShampooAntiAlerg = new javax.swing.JRadioButton();
        btnLimparShampoo = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnConsultar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblBanho = new javax.swing.JTable();
        btnAtualizar = new javax.swing.JButton();
        btnExBanId = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ListarTab = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("ID:");

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        PanelCliente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbDadosCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbDadosCliente.setText("Dados do Cliente: ");

        lbNome.setText("Nome: ");

        txtNomeCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeClienteActionPerformed(evt);
            }
        });

        lbEndereco.setText("Endereço:");

        txtEndereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEnderecoActionPerformed(evt);
            }
        });

        lbTelefone.setText("Telefone:");

        txtTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefoneActionPerformed(evt);
            }
        });

        btnLimparCliente.setText("Limpar");
        btnLimparCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelClienteLayout = new javax.swing.GroupLayout(PanelCliente);
        PanelCliente.setLayout(PanelClienteLayout);
        PanelClienteLayout.setHorizontalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbNome)
                            .addComponent(lbTelefone)
                            .addComponent(lbEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                            .addComponent(txtNomeCliente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtTelefone, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(PanelClienteLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbDadosCliente)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClienteLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparCliente)))
                .addContainerGap())
        );
        PanelClienteLayout.setVerticalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbDadosCliente)
                .addGap(18, 18, 18)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbNome))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTelefone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbEndereco)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                .addComponent(btnLimparCliente)
                .addContainerGap())
        );

        PanelDadosAnimal.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelDadosAnimal.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        LbDadosAnimal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        LbDadosAnimal.setText("Dados do animal: ");

        LbNomeAnimal.setText("Nome: ");

        LbRacaAnimal.setText("Raça:");

        txtNomeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeAnimalActionPerformed(evt);
            }
        });

        txtRacaAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRacaAnimalActionPerformed(evt);
            }
        });

        LbPeso.setText("Peso (KG): ");

        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });

        txtIdadeAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdadeAnimalActionPerformed(evt);
            }
        });

        lbIdadeAnimal.setText("Idade (anos): ");

        btnLimparAnimal.setText("Limpar");
        btnLimparAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAnimalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelDadosAnimalLayout = new javax.swing.GroupLayout(PanelDadosAnimal);
        PanelDadosAnimal.setLayout(PanelDadosAnimalLayout);
        PanelDadosAnimalLayout.setHorizontalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LbNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LbPeso)
                            .addComponent(LbRacaAnimal)
                            .addComponent(lbIdadeAnimal))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNomeAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                            .addComponent(txtPeso, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtRacaAnimal, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtIdadeAnimal)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelDadosAnimalLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLimparAnimal)))
                .addContainerGap())
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LbDadosAnimal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelDadosAnimalLayout.setVerticalGroup(
            PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelDadosAnimalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LbDadosAnimal)
                .addGap(18, 18, 18)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbNomeAnimal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LbRacaAnimal)
                    .addComponent(txtRacaAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbPeso))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelDadosAnimalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdadeAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbIdadeAnimal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLimparAnimal)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        PanelAgendamento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelAgendamento.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbAgendamento.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbAgendamento.setText("Agendamento: ");

        lbData.setText("Data (formato: yyyy-MM-dd):");

        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        lbHorario.setText("Horario (formato: HH:mm):");

        txtHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHorarioActionPerformed(evt);
            }
        });

        btnLimparAgenda.setText("Limpar");
        btnLimparAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparAgendaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelAgendamentoLayout = new javax.swing.GroupLayout(PanelAgendamento);
        PanelAgendamento.setLayout(PanelAgendamentoLayout);
        PanelAgendamentoLayout.setHorizontalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLimparAgenda))
                    .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                        .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtData, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                                    .addComponent(lbData)
                                    .addComponent(lbHorario)
                                    .addComponent(txtHorario)))
                            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lbAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        PanelAgendamentoLayout.setVerticalGroup(
            PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbAgendamento)
                .addGap(18, 18, 18)
                .addComponent(lbData)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbHorario)
                .addGroup(PanelAgendamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelAgendamentoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addComponent(btnLimparAgenda)
                        .addGap(14, 14, 14))))
        );

        PanelTipoBanho.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelTipoBanho.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbEscolhaTipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbEscolhaTipo.setText("Escolha um tipo de banho: ");

        BGtipoBanho.add(RadioBanhoNormal);
        RadioBanhoNormal.setText("Normal");
        RadioBanhoNormal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioBanhoNormalActionPerformed(evt);
            }
        });

        BGtipoBanho.add(RadioBanhoHidra);
        RadioBanhoHidra.setText("Hidratação");
        RadioBanhoHidra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioBanhoHidraActionPerformed(evt);
            }
        });

        BGtipoBanho.add(RadioBanhoRecons);
        RadioBanhoRecons.setText("Reconstrução");
        RadioBanhoRecons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioBanhoReconsActionPerformed(evt);
            }
        });

        btnLimparTipoBanho.setText("Limpar");
        btnLimparTipoBanho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparTipoBanhoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelTipoBanhoLayout = new javax.swing.GroupLayout(PanelTipoBanho);
        PanelTipoBanho.setLayout(PanelTipoBanhoLayout);
        PanelTipoBanhoLayout.setHorizontalGroup(
            PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addGroup(PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RadioBanhoHidra)
                            .addComponent(RadioBanhoNormal)
                            .addComponent(RadioBanhoRecons))
                        .addGap(0, 174, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelTipoBanhoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparTipoBanho)))
                .addContainerGap())
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbEscolhaTipo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelTipoBanhoLayout.setVerticalGroup(
            PanelTipoBanhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoBanhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbEscolhaTipo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RadioBanhoNormal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RadioBanhoHidra)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioBanhoRecons)
                .addGap(59, 59, 59)
                .addComponent(btnLimparTipoBanho)
                .addGap(78, 78, 78))
        );

        PanelTipoShampoo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PanelTipoShampoo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbTipoShampoo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbTipoShampoo.setText("Escolha um tipo de shampoo: ");

        BGtipoShampoo.add(RadioShampooNeutro);
        RadioShampooNeutro.setText("Neutro");
        RadioShampooNeutro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioShampooNeutroActionPerformed(evt);
            }
        });

        BGtipoShampoo.add(RadioShampooLimpPro);
        RadioShampooLimpPro.setText("Limpeza profunda");
        RadioShampooLimpPro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioShampooLimpProActionPerformed(evt);
            }
        });

        BGtipoShampoo.add(RadioShampooAntiAlerg);
        RadioShampooAntiAlerg.setText("Anti-alérgico");
        RadioShampooAntiAlerg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioShampooAntiAlergActionPerformed(evt);
            }
        });

        btnLimparShampoo.setText("Limpar");
        btnLimparShampoo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparShampooActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelTipoShampooLayout = new javax.swing.GroupLayout(PanelTipoShampoo);
        PanelTipoShampoo.setLayout(PanelTipoShampooLayout);
        PanelTipoShampooLayout.setHorizontalGroup(
            PanelTipoShampooLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoShampooLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(PanelTipoShampooLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelTipoShampooLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimparShampoo)
                        .addGap(10, 10, 10))
                    .addGroup(PanelTipoShampooLayout.createSequentialGroup()
                        .addGroup(PanelTipoShampooLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RadioShampooLimpPro)
                            .addComponent(RadioShampooNeutro)
                            .addComponent(RadioShampooAntiAlerg))
                        .addContainerGap(173, Short.MAX_VALUE))))
            .addGroup(PanelTipoShampooLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbTipoShampoo)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        PanelTipoShampooLayout.setVerticalGroup(
            PanelTipoShampooLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTipoShampooLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbTipoShampoo)
                .addGap(12, 12, 12)
                .addComponent(RadioShampooNeutro)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioShampooLimpPro)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioShampooAntiAlerg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnLimparShampoo)
                .addGap(17, 17, 17))
        );

        btnSalvar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnSair.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnConsultar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        tblBanho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome Cliente", "Endereço", "Telefone", "Nome Animal", "Raça", "Peso", "Idade", "Data ", "Horário", "Tipo De Banho", "Tipo De Shampoo", "Duração (min.)", "Preço"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblBanho);
        if (tblBanho.getColumnModel().getColumnCount() > 0) {
            tblBanho.getColumnModel().getColumn(0).setMinWidth(40);
            tblBanho.getColumnModel().getColumn(1).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(2).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(3).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(4).setMinWidth(90);
            tblBanho.getColumnModel().getColumn(5).setMinWidth(80);
            tblBanho.getColumnModel().getColumn(6).setMinWidth(60);
            tblBanho.getColumnModel().getColumn(7).setMinWidth(60);
            tblBanho.getColumnModel().getColumn(8).setMinWidth(70);
            tblBanho.getColumnModel().getColumn(9).setMinWidth(70);
            tblBanho.getColumnModel().getColumn(10).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(11).setMinWidth(120);
            tblBanho.getColumnModel().getColumn(12).setMinWidth(100);
            tblBanho.getColumnModel().getColumn(13).setMinWidth(60);
        }

        btnAtualizar.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        btnExBanId.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnExBanId.setText("Excluir pelo ID");
        btnExBanId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExBanIdActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel1.setText("Agendamento de Banho");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Tabela de agendamentos de banho");

        ListarTab.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        ListarTab.setText("Atualizar tabela");
        ListarTab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarTabActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelMainLayout = new javax.swing.GroupLayout(PanelMain);
        PanelMain.setLayout(PanelMainLayout);
        PanelMainLayout.setHorizontalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PanelTipoShampoo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PanelAgendamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(PanelTipoBanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(34, 34, 34)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ListarTab, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(805, 805, 805)
                        .addComponent(jLabel1))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(btnExBanId)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAtualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnConsultar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(77, Short.MAX_VALUE))
        );
        PanelMainLayout.setVerticalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(jLabel3)
                        .addGap(2, 2, 2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelMainLayout.createSequentialGroup()
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ListarTab))
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(PanelDadosAnimal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PanelTipoBanho, javax.swing.GroupLayout.PREFERRED_SIZE, 217, Short.MAX_VALUE)
                            .addComponent(PanelAgendamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PanelTipoShampoo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExBanId)
                    .addComponent(btnAtualizar)
                    .addComponent(btnConsultar)
                    .addComponent(btnSalvar)
                    .addComponent(btnSair))
                .addGap(188, 188, 188))
        );

        jScrollPane1.setViewportView(PanelMain);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1688, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 851, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExBanIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExBanIdActionPerformed
        excluir();
        listarTab();

    }//GEN-LAST:event_btnExBanIdActionPerformed

    private void ListarTabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarTabActionPerformed
        listarTab();
    }//GEN-LAST:event_ListarTabActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        atualizar();

    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        consultar();        // TODO add your handling code here:
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?", "Cancelar Agendamento", WIDTH);
        if(sair == 0){
            limpar();
            this.dispose();
        }
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        ba = new Banho();
        if(txtNomeCliente.getText().isEmpty() || txtEndereco.getText().isEmpty() || txtTelefone.getText().isEmpty() ||
            txtNomeAnimal.getText().isEmpty() || txtPeso.getText().isEmpty() || txtRacaAnimal.getText().isEmpty() || txtIdadeAnimal.getText().isEmpty() ||
            txtData.getText().isEmpty() || txtHorario.getText().isEmpty() || txtId.getText().isEmpty() ||
            !RadioBanhoHidra.isSelected() && !RadioBanhoNormal.isSelected() && !RadioBanhoRecons.isSelected() ||
            !RadioShampooNeutro.isSelected() && !RadioShampooLimpPro.isSelected() && !RadioShampooAntiAlerg.isSelected()){
            JOptionPane.showMessageDialog(this, "Preencha todos os campos.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }else if(salvarCliente(ba) == null || salvarDadosAnimal(ba) == null || salvarAgendamento(ba) == null || salvarId(ba) == null){
            JOptionPane.showMessageDialog(this, "Corrija os erros antes de continuar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
        else if(!RadioBanhoHidra.isSelected() && !RadioBanhoNormal.isSelected() && !RadioBanhoRecons.isSelected()){
            JOptionPane.showMessageDialog(this, "Por favor, selecione uma das opções de banho!", "ERRO" , JOptionPane.ERROR_MESSAGE);
        }
        else if(!RadioShampooNeutro.isSelected() && !RadioShampooLimpPro.isSelected() && !RadioShampooAntiAlerg.isSelected()){
            JOptionPane.showMessageDialog(this, "Por favor, selecione uma das opções de shampoo!", "ERRO" , JOptionPane.ERROR_MESSAGE);
        }
        else {

            // Algum radio button está selecionado
            if(RadioBanhoHidra.isSelected() ){
                ba.setTipoDeBanho(RadioBanhoHidra.getText());
            }else if(RadioBanhoNormal.isSelected()){
                ba.setTipoDeBanho(RadioBanhoNormal.getText());
            }else{
                ba.setTipoDeBanho(RadioBanhoRecons.getText());
            }
            if(RadioShampooNeutro.isSelected() ){
                ba.setTipoDeShampoo(RadioShampooNeutro.getText());
            }else if(RadioShampooLimpPro.isSelected()){
                ba.setTipoDeShampoo(RadioShampooLimpPro.getText());
            }else{
                ba.setTipoDeShampoo(RadioShampooAntiAlerg.getText());
            }
            ba = salvarId(ba);
            ba = salvarCliente(ba);
            ba = salvarDadosAnimal(ba);
            ba = salvarAgendamento(ba);
            ba.calcPreco();
            ba = gerBan.insBanho(ba);

            if(ba != null){
                JOptionPane.showMessageDialog(null, "Agendamento realizado com sucesso!", "Salvando dados", JOptionPane.INFORMATION_MESSAGE);
                listarTab();
                limpar();
            }
            else{
                JOptionPane.showMessageDialog(null, "Já existe um agendamento com esse ID", "Erro de agendamento", JOptionPane.ERROR_MESSAGE);
                txtId.setText("");
                txtId.requestFocus();
            }

        }

        //verificando tipo de banho

        //verificando tipo de shampoo

    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnLimparShampooActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparShampooActionPerformed
        BGtipoShampoo.clearSelection();
    }//GEN-LAST:event_btnLimparShampooActionPerformed

    private void RadioShampooAntiAlergActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioShampooAntiAlergActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioShampooAntiAlergActionPerformed

    private void RadioShampooLimpProActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioShampooLimpProActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioShampooLimpProActionPerformed

    private void RadioShampooNeutroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioShampooNeutroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioShampooNeutroActionPerformed

    private void btnLimparTipoBanhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparTipoBanhoActionPerformed
        BGtipoBanho.clearSelection();
    }//GEN-LAST:event_btnLimparTipoBanhoActionPerformed

    private void RadioBanhoReconsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioBanhoReconsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioBanhoReconsActionPerformed

    private void RadioBanhoHidraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioBanhoHidraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioBanhoHidraActionPerformed

    private void RadioBanhoNormalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioBanhoNormalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioBanhoNormalActionPerformed

    private void btnLimparAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAgendaActionPerformed
        txtHorario.setText("");
        txtData.setText("");
    }//GEN-LAST:event_btnLimparAgendaActionPerformed

    private void txtHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHorarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHorarioActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void btnLimparAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparAnimalActionPerformed
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
    }//GEN-LAST:event_btnLimparAnimalActionPerformed

    private void txtIdadeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdadeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdadeAnimalActionPerformed

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoActionPerformed

    private void txtRacaAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRacaAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRacaAnimalActionPerformed

    private void txtNomeAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeAnimalActionPerformed

    private void btnLimparClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparClienteActionPerformed
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
    }//GEN-LAST:event_btnLimparClienteActionPerformed

    private void txtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneActionPerformed

    private void txtEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnderecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEnderecoActionPerformed

    private void txtNomeClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeClienteActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed
    
    public void atualizar(){
        ba = new Banho();
        boolean valido = true;
        int id = 0;
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do agendamento que será atualizado."));
            
         }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            valido = false;
        }
        
        if(valido){
            ba.setId(id);
            ba = gerBan.consBanho(ba);
            if(ba != null){
                
                FormAtuBa.getFormAtuaBa().dados(ba);
                FormAtuBa.getFormAtuaBa().setVisible(true);
                     
            }else{
                JOptionPane.showMessageDialog(null, "Não existe agendamento com esse ID", "Erro", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    
    public Banho salvarId(Banho ba){
        boolean valido = true;
        
        try{
            ba.setId(Integer.parseInt(txtId.getText()));
        }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números no campo ID.", "Erro de agendamento", JOptionPane.ERROR_MESSAGE);
            valido = false;
            txtId.setText("");
            txtId.requestFocus();
            
        }
        if(valido){
            return ba;
        }
        else{
            return null;
        }
    }
public Banho salvarCliente(Banho ba) {
    boolean valido = true; // Controle de validação

    // Validação do nome
    try {
        ba.getAgenda().getAnimal().getDono().setNome(txtNomeCliente.getText());
    } catch (NomeNegException nne) {
        JOptionPane.showMessageDialog(this, "Informe apenas letras no NOME", "Erro", JOptionPane.ERROR_MESSAGE);
        txtNomeCliente.setText("");
        valido = false;
    }

    // Validação de telefone e endereço (apenas verificando campos obrigatórios)
    if (txtTelefone.getText().isEmpty() || txtEndereco.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Preencha todos os campos obrigatórios", "Erro", JOptionPane.ERROR_MESSAGE);
        valido = false;
    }

    // Se tudo estiver válido, salvar os dados
    if (valido) {
        ba.getAgenda().getAnimal().getDono().setFone(txtTelefone.getText());
        ba.getAgenda().getAnimal().getDono().setEndereco(txtEndereco.getText());
        return ba; // Retorna apenas se todas as validações passarem
    } else {
        return null; // Não salvar enquanto houver erro
    }
}//Fim do método

//salvando dados do animal
public Banho salvarDadosAnimal(Banho ba){
    ba.getAgenda().getAnimal().setNome(txtNomeAnimal.getText());
    boolean valido = true;
		
    try {
        ba.getAgenda().getAnimal().setPeso(Double.parseDouble(txtPeso.getText()));
        
    }catch (NumNegException p) {
        JOptionPane.showMessageDialog(null, "Informe um número maior que 0 no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE );
        valido = false;
        txtPeso.setText("");
    }catch (NumberFormatException nfe) {
        JOptionPane.showMessageDialog(null,"Informe apenas números no campo PESO.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtPeso.setText("");
    }
    
    try {
	ba.getAgenda().getAnimal().setIdade(Integer.parseInt(txtIdadeAnimal.getText()));
	
    } catch (IdadeNegException ine) {
        JOptionPane.showMessageDialog(null,"Informe um número maior que 0 para IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtIdadeAnimal.setText("");
    } catch (NumberFormatException nfe) {
        JOptionPane.showMessageDialog(null,"Informe um número inteiro no campo IDADE.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtIdadeAnimal.setText("");
    }   
		
   
    try {
	ba.getAgenda().getAnimal().setRaca(txtRacaAnimal.getText());
	
    }catch(RacaNumException rne) {
        JOptionPane.showMessageDialog(null,"Informe apenas letras no campo RAÇA.", "ERRO", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtRacaAnimal.setText("");
    }   
        
    if (valido){
        return ba;
    }
    else{
        return null;
    } 
} //Fim do metodo


//Salvar agendamento
public Banho salvarAgendamento(Banho ba){
    boolean valido = true;
    //entrada da data
    try {
	ba.getAgenda().setData(LocalDate.parse(txtData.getText()));
        
    }catch (DateTimeParseException e) {
	JOptionPane.showMessageDialog(null, "Formato de data inválido! Por favor, use o formato: yyyy-MM-dd.", "Erro", JOptionPane.ERROR_MESSAGE);
        txtData.setText("");
        valido = false;
    }
		
    //entrada da hora
    try {
	ba.getAgenda().setHora(LocalTime.parse(txtHorario.getText()));
	
    } catch (IllegalArgumentException e) {
	JOptionPane.showMessageDialog(null, "Este horário está fora do horário de funcionamento (8 horas - 18 horas)!  ", "Erro", JOptionPane.ERROR_MESSAGE);
        valido = false;
        txtHorario.setText(""); 
    }
    catch (DateTimeParseException e) {
	JOptionPane.showMessageDialog(null, "Formato de horário inválido! Por favor, use o formato: HH:mm.", "Erro", JOptionPane.ERROR_MESSAGE);
	valido = false;
        txtHorario.setText(""); 
        
    }   
    if(valido){
        return ba;
    }
    else{
        return null;
    }
} //fim do metodo 
    
//metodo Limpar tudo
    public void limpar(){
        txtNomeCliente.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
        txtNomeAnimal.setText("");
        txtRacaAnimal.setText("");
        txtIdadeAnimal.setText("");
        txtPeso.setText("");
        txtHorario.setText("");
        txtData.setText("");
        BGtipoBanho.clearSelection();
        BGtipoShampoo.clearSelection();
        txtId.setText("");
    }
    
    public void consultar(){
        ba = new Banho();
        
        int id = 0;
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do agendamento para a consulta."));
            ba.setId(id);
            ba = gerBan.consBanho(ba);
            if(ba != null){
                   FormConsBa.getFormConsBa().listarTabB(ba);
                   FormConsBa.getFormConsBa().setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Não existe agendamento com esse ID", "Erro", JOptionPane.INFORMATION_MESSAGE);
            }
         }
        catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            
        }
        
        
        
            
        
        
        
        
    }
    
    public void listarTab(){
          DefaultTableModel modelo = (DefaultTableModel) tblBanho.getModel();
          int posLin = 0;
          
         modelo.setRowCount(posLin);
        
        for(Banho b: gerBan.geraGerBan().getGerBan() ){
            modelo.insertRow(posLin, new Object []{b.getId(), b.getAgenda().getAnimal().getDono().getNome(),
                                b.getAgenda().getAnimal().getDono().getEndereco(),
                                b.getAgenda().getAnimal().getDono().getFone(),
                                b.getAgenda().getAnimal().getNome(),
                                b.getAgenda().getAnimal().getRaca(),
                                b.getAgenda().getAnimal().getPeso(),
                                b.getAgenda().getAnimal().getIdade(),
                                b.getAgenda().getData(),
                                b.getAgenda().getHora(),
                                b.getTipoDeBanho(),
                                b.getTipoDeShampoo(),
                                b.duracaoServico(),
                                b.getPreco()
                                });
        }
    }
    
    public void excluir(){
        Banho ba = new Banho();
        int id;
        
        try{
            id = Integer.parseInt(JOptionPane.showInputDialog("Informe um ID para exclusão"));
            ba.setId(id);
            ba = gerBan.consBanho(ba);
            if(ba != null){
                int ver = JOptionPane.showConfirmDialog(null, "Deseja realmente excluir esse agendamento?", "Confirmação de exclusão", JOptionPane.YES_NO_CANCEL_OPTION);
                if( ver == 0){
                    gerBan.delBanhoId(ba);
                    JOptionPane.showMessageDialog(null, "Agendamento  excluído com sucesso.", "Exclusão de agendamento", 1);
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Não existe um agendemento com esse ID", "Erro de Exclusão", JOptionPane.ERROR_MESSAGE);
            }
            
        }catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "Informe apenas números", "Erro", JOptionPane.ERROR_MESSAGE);
            
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormBanho().setVisible(true);
                    
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BGtipoBanho;
    private javax.swing.ButtonGroup BGtipoShampoo;
    private javax.swing.JLabel LbDadosAnimal;
    private javax.swing.JLabel LbNomeAnimal;
    private javax.swing.JLabel LbPeso;
    private javax.swing.JLabel LbRacaAnimal;
    private javax.swing.JButton ListarTab;
    private javax.swing.JPanel PanelAgendamento;
    private javax.swing.JPanel PanelCliente;
    private javax.swing.JPanel PanelDadosAnimal;
    private javax.swing.JPanel PanelMain;
    private javax.swing.JPanel PanelTipoBanho;
    private javax.swing.JPanel PanelTipoShampoo;
    private javax.swing.JRadioButton RadioBanhoHidra;
    private javax.swing.JRadioButton RadioBanhoNormal;
    private javax.swing.JRadioButton RadioBanhoRecons;
    private javax.swing.JRadioButton RadioShampooAntiAlerg;
    private javax.swing.JRadioButton RadioShampooLimpPro;
    private javax.swing.JRadioButton RadioShampooNeutro;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnExBanId;
    private javax.swing.JButton btnLimparAgenda;
    private javax.swing.JButton btnLimparAnimal;
    private javax.swing.JButton btnLimparCliente;
    private javax.swing.JButton btnLimparShampoo;
    private javax.swing.JButton btnLimparTipoBanho;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbAgendamento;
    private javax.swing.JLabel lbDadosCliente;
    private javax.swing.JLabel lbData;
    private javax.swing.JLabel lbEndereco;
    private javax.swing.JLabel lbEscolhaTipo;
    private javax.swing.JLabel lbHorario;
    private javax.swing.JLabel lbIdadeAnimal;
    private javax.swing.JLabel lbNome;
    private javax.swing.JLabel lbTelefone;
    private javax.swing.JLabel lbTipoShampoo;
    private javax.swing.JTable tblBanho;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtHorario;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtIdadeAnimal;
    private javax.swing.JTextField txtNomeAnimal;
    private javax.swing.JTextField txtNomeCliente;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtRacaAnimal;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
