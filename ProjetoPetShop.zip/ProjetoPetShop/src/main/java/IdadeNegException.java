//Joao Vitor Furquim de Brito - RA: 2647990

public class IdadeNegException extends Exception{
	public IdadeNegException(){}
	
}