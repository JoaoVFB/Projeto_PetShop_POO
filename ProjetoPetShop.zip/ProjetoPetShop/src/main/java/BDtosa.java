//Joao Vitor Furquim de Brito - RA:2647990

import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joaov
 */
public class BDtosa{
    
        private Tosa to;
        private List<Tosa> gerTosa;
        
        private static BDtosa bdTosaUnic;
      
        private BDtosa(){
            to = new Tosa();
            gerTosa = new ArrayList<Tosa>();
        }
         //MÉTODO SINGLETON
	public static BDtosa geraGerTos(){
            if(bdTosaUnic == null){
                bdTosaUnic = new BDtosa();
            }
            return bdTosaUnic;
        }
        
        public List<Tosa> getGerTos(){
            return gerTosa;
        }
        
	//Consultar dados
	public Tosa consTosa(Tosa to){
		for(int i = 0; i < gerTosa.size(); i++){
			if(to.getId() == gerTosa.get(i).getId()){
				return gerTosa.get(i);
			}
		}
		return null;
	}//fim consTosa
	
	//inserir dados
	public Tosa insTosa(Tosa to) {
		if(consTosa(to) == null) {
			gerTosa.add(to);
			return to;
		}else {
			return null;
		}
	}//fim do insTosa
	
	//atualizar Tosa
	public Tosa atualizarTosa(Tosa to){ //Nao atualiza o num, apenas os demais campos
		for(int i = 0; i < gerTosa.size(); i++){
			if(to.getId() == gerTosa.get(i).getId()){
                            to = gerTosa.get(i);
                            gerTosa.set(i, to);  
                            return gerTosa.get(i);
			}
		}
                return null;
	}//fim do atualizar
        
        //Excluir Tosa
        public Tosa delTosaId(Tosa to){
           
            Tosa to1 = consTosa(to);
            if(to1 != null){
                gerTosa.remove(to1);
                return null;
            }
            else{
                return to;
            }
	
        }//fim do delTosaId
	
	

}