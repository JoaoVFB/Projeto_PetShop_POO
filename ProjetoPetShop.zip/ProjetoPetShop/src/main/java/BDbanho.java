//Joao Vitor Furquim de Brito - RA:2647990

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;



public class BDbanho {
    
        private Banho ba;
        private List<Banho> gerBan;
        
        private static BDbanho bdBanhoUnic;
      
        private BDbanho(){
            ba = new Banho();
            gerBan = new ArrayList<Banho>();
        }
         //MÉTODO SINGLETON
	public static BDbanho geraGerBan(){
            if(bdBanhoUnic == null){
                bdBanhoUnic = new BDbanho();
            }
            return bdBanhoUnic;
        }
        
        public List<Banho> getGerBan(){
            return gerBan;
        }
        
	//Consultar dados
	public Banho consBanho(Banho ba){
		for(int i = 0; i < gerBan.size(); i++){
			if(ba.getId() == gerBan.get(i).getId()){
				return gerBan.get(i);
			}
		}
		return null;
	}//fim consBanNum
	
	//inserir dados
	public Banho insBanho(Banho ba) {
		if(consBanho(ba) == null) {
			gerBan.add(ba);
			return ba;
		}else {
			return null;
		}
	}//fim do insBanho
	
	//atualizar banho
	public Banho atualizarBanho(Banho ba){ //Nao atualiza o num, apenas os demais campos
		for(int i = 0; i < gerBan.size(); i++){
			if(ba.getId() == gerBan.get(i).getId()){
                            ba = gerBan.get(i);
                            gerBan.set(i, ba);  
                            return gerBan.get(i);
			}
		}
                return null;
	}//fim atualizaPesCpf
	
        //Excluir Banho
        public Banho delBanhoId(Banho ba){
           
            Banho ba1 = consBanho(ba);
            if(ba1 != null){
                gerBan.remove(ba1);
                return null;
            }
            else{
                return ba;
            }
	
        }//fim do delBanhoId
	
	

}