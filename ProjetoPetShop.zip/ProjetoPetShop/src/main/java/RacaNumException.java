//Joao Vitor Furquim de Brito - RA: 2647990

public class RacaNumException extends Exception {
	public RacaNumException(){}
	
}
