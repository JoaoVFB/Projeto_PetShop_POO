//Joao Vitor Furquim de Brito - RA: 2647990

public class Cliente {
	
	private String nome;	
	private String fone;
	private String endereco;
	
	
	
	public Cliente() {
		nome = "";
		fone = "";
		endereco = "";
		
	}
	
	public Cliente(String nome, String fone, String endereco) {
		this.nome = nome;
		this.fone = fone;
		this.endereco = endereco;
		}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) throws NomeNegException{
		for(int i=0; i< nome.length(); i++) {
			char c = nome.charAt(i);
			if(Character.isDigit(c)) {
				throw new NomeNegException();
			}
		}
		this.nome = nome;
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}



	
}
